# A2A Protocol Demo: Retail Multi-Agent System

A teaching demo for Google's Agent-to-Agent (A2A) protocol using a retail multi-agent scenario.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run all agents and frontend
./run_agents.sh
```

Then open http://localhost:7860 in your browser.

## Manual Startup

Run each agent in a separate terminal:

```bash
# Terminal 1: Demand Agent
python agents/demand_agent/agent.py

# Terminal 2: Pricing Agent
python agents/pricing_agent/agent.py

# Terminal 3: Inventory Agent
python agents/inventory_agent/agent.py

# Terminal 4: Frontend
python frontend/app.py
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     Gradio Frontend (:7860)                     │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│              Inventory Planning Agent (:8003)                   │
│                        [Orchestrator]                           │
└──────────────┬──────────────────────────────┬───────────────────┘
               │                              │
               ▼                              ▼
┌──────────────────────────┐    ┌──────────────────────────┐
│  Demand Forecasting      │    │  Store Pricing           │
│  Agent (:8001)           │    │  Agent (:8002)           │
└──────────────────────────┘    └──────────────────────────┘
```

## Agents

| Agent | Port | Purpose |
|-------|------|---------|
| Demand Forecasting | 8001 | Predicts product demand |
| Store Pricing | 8002 | Calculates optimal prices |
| Inventory Planning | 8003 | Orchestrates decisions |

## A2A Endpoints

Each agent exposes:
- `GET /.well-known/agent.json` - Agent Card (discovery)
- `POST /tasks/send` - Execute a task

## Files

```
a2a-demo/
├── case_study.md         # Teaching material
├── SAMPLE_QUESTIONS.md   # Demo questions
├── requirements.txt      # Python dependencies
├── run_agents.sh         # Startup script
│
├── common/               # Shared A2A types
│   ├── types.py
│   └── a2a_client.py
│
├── agents/
│   ├── demand_agent/     # LangGraph agent
│   ├── pricing_agent/    # LangGraph agent
│   └── inventory_agent/  # LangGraph orchestrator
│
└── frontend/
    └── app.py            # Gradio UI
```

