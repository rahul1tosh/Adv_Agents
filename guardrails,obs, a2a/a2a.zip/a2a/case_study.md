# A2A Protocol Case Study: Retail Multi-Agent System

## Overview

This case study teaches Google's **Agent-to-Agent (A2A) Protocol** through a practical retail scenario involving three interconnected agents that collaborate to optimize store operations.

---

## Learning Objectives 

By the end of this session, participants will:
1. Understand the A2A protocol specification and its key components
2. Know how agents discover and communicate with each other
3. Implement a working multi-agent system using A2A
4. See how agents negotiate and collaborate on complex tasks

---

## Part 1: Introduction to A2A Protocol 

### What is A2A?

A2A (Agent-to-Agent) is an open protocol that enables AI agents to:
- **Discover** each other's capabilities
- **Communicate** using a standardized format
- **Collaborate** on complex tasks across organizational boundaries
- **Delegate** work to specialized agents

### Key A2A Concepts

```
┌─────────────────────────────────────────────────────────────────┐
│                        A2A ARCHITECTURE                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌──────────────┐    Agent Card     ┌──────────────┐          │
│   │   Agent A    │◄─────────────────►│   Agent B    │          │
│   │  (Client)    │                   │  (Server)    │          │
│   └──────┬───────┘                   └──────┬───────┘          │
│          │                                  │                   │
│          │         Task Request             │                   │
│          │─────────────────────────────────►│                   │
│          │                                  │                   │
│          │         Task Response            │                   │
│          │◄─────────────────────────────────│                   │
│          │                                  │                   │
│          │      Artifact/Message            │                   │
│          │◄────────────────────────────────►│                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Core Components

| Component | Description |
|-----------|-------------|
| **Agent Card** | JSON document describing an agent's capabilities, skills, and endpoint (similar to OpenAPI spec) |
| **Task** | A unit of work with a lifecycle (submitted → working → completed/failed) |
| **Message** | Communication between agents (can contain text, files, structured data) |
| **Artifact** | Output produced by an agent during task execution |
| **Skill** | A specific capability an agent advertises |

### Agent Card Structure

```json
{
  "name": "Demand Forecasting Agent",
  "description": "Predicts product demand using ML models",
  "url": "http://localhost:8001",
  "version": "1.0.0",
  "capabilities": {
    "streaming": true,
    "pushNotifications": false
  },
  "skills": [
    {
      "id": "forecast_demand",
      "name": "Forecast Product Demand",
      "description": "Predict demand for products over a time period",
      "inputModes": ["text/plain", "application/json"],
      "outputModes": ["application/json"]
    }
  ]
}
```

---

## Part 2: The Case Study Scenario 

### Business Context

A retail chain needs to optimize operations across three domains:
1. **Pricing** - Dynamic pricing based on market conditions
2. **Inventory** - Stock level optimization and reorder planning
3. **Demand** - Forecasting future product demand

### The Three Agents (Chained A2A Flow)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    RETAIL MULTI-AGENT SYSTEM                            │
│                      (Chained A2A Calls)                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────┐                                                │
│  │  INVENTORY PLANNING │                                                │
│  │       AGENT         │  Entry point - orchestrates the workflow       │
│  │     (:8003)         │                                                │
│  │                     │                                                │
│  │  Skills:            │                                                │
│  │  - plan_inventory   │                                                │
│  │  - check_reorder    │                                                │
│  └──────────┬──────────┘                                                │
│             │                                                           │
│             │ 1. A2A call: forecast_demand                              │
│             ▼                                                           │
│  ┌─────────────────────┐         ┌─────────────────────┐               │
│  │  DEMAND FORECASTING │         │   STORE PRICING     │               │
│  │       AGENT         │────────►│       AGENT         │               │
│  │     (:8001)         │         │     (:8002)         │               │
│  │                     │ 2. A2A  │                     │               │
│  │  Skills:            │  call:  │  Skills:            │               │
│  │  - forecast_demand  │ price   │  - calculate_price  │               │
│  │  - analyze_trends   │◄────────│  - analyze_margins  │               │
│  └─────────────────────┘ 3. price└─────────────────────┘               │
│             │             context                                       │
│             │ 4. forecast + pricing                                     │
│             └──────────────────────────────────────────►                │
│                                      back to Inventory Agent            │
└─────────────────────────────────────────────────────────────────────────┘
```

### Agent Responsibilities

#### 1. Store Inventory Planning Agent (Orchestrator)
- **Entry point** for user requests
- Determines optimal stock levels
- Generates reorder recommendations
- **Calls Demand Agent** via A2A to get forecasts
- **Inputs**: Product ID, current stock, warehouse capacity
- **Outputs**: Reorder quantity, timing, comprehensive plan

#### 2. Demand Forecasting Agent
- Predicts future demand for products
- Analyzes historical sales trends
- **Calls Pricing Agent** via A2A to get price context
- Adjusts forecasts based on pricing strategy
- **Inputs**: Product ID, time range, historical data
- **Outputs**: Demand forecast with pricing context

#### 3. Store Pricing Agent
- Calculates optimal prices
- Considers margins, competition, and demand elasticity
- Determines pricing strategy (premium/standard/markdown)
- **Inputs**: Product ID, cost, competitor prices, inventory status
- **Outputs**: Recommended price, pricing strategy

---

## Part 3: A2A Communication Flow (15 minutes)

### Scenario: "Should we reorder Product X?"

This example shows **chained A2A calls**: Inventory → Demand → Pricing

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    CHAINED A2A COMMUNICATION FLOW                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  User/System         Inventory           Demand            Pricing          │
│      │                 Agent              Agent             Agent           │
│      │                   │                  │                 │             │
│      │  1. "Plan         │                  │                 │             │
│      │   inventory"      │                  │                 │             │
│      │──────────────────►│                  │                 │             │
│      │                   │                  │                 │             │
│      │                   │ 2. A2A Task:     │                 │             │
│      │                   │ forecast_demand  │                 │             │
│      │                   │─────────────────►│                 │             │
│      │                   │                  │                 │             │
│      │                   │                  │ 3. A2A Task:    │             │
│      │                   │                  │ calculate_price │             │
│      │                   │                  │────────────────►│             │
│      │                   │                  │                 │             │
│      │                   │                  │ 4. Artifact:    │             │
│      │                   │                  │ {price: $59.99, │             │
│      │                   │                  │  strategy:      │             │
│      │                   │                  │  "standard"}    │             │
│      │                   │                  │◄────────────────│             │
│      │                   │                  │                 │             │
│      │                   │ 5. Artifact:     │                 │             │
│      │                   │ {forecast: 500,  │                 │             │
│      │                   │  trend: "up",    │                 │             │
│      │                   │  price: $59.99,  │                 │             │
│      │                   │  strategy: "std"}│                 │             │
│      │                   │◄─────────────────│                 │             │
│      │                   │                  │                 │             │
│      │ 6. Response:      │                  │                 │             │
│      │ "Reorder 300      │                  │                 │             │
│      │  units"           │                  │                 │             │
│      │◄──────────────────│                  │                 │             │
│      │                   │                  │                 │             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Key Insight: Chained A2A Calls

Notice how the **Demand Agent acts as both client AND server**:
- It receives a task from the Inventory Agent (acts as server)
- It sends a task to the Pricing Agent (acts as client)
- It combines the pricing response with its own forecast
- It returns the combined result to the Inventory Agent

This demonstrates a core A2A capability: **agents can chain calls to other agents**.

### A2A Task Lifecycle

```
           ┌────────────┐
           │ SUBMITTED  │  (Task created)
           └─────┬──────┘
                 │
                 ▼
           ┌────────────┐
           │  WORKING   │  (Agent processing)
           └─────┬──────┘
                 │
        ┌────────┴────────┐
        ▼                 ▼
┌────────────┐    ┌────────────┐
│ COMPLETED  │    │  FAILED    │
└────────────┘    └────────────┘
```

### Message Format Example

```json
{
  "jsonrpc": "2.0",
  "method": "tasks/send",
  "params": {
    "id": "task-123",
    "message": {
      "role": "user",
      "parts": [
        {
          "type": "text",
          "text": "Forecast demand for product SKU-001 for Q1 2025"
        }
      ]
    }
  }
}
```

---

## Part 4: Implementation Architecture (5 minutes)

### Project Structure

```
a2a-demo/
├── common/
│   ├── types.py           # A2A protocol types
│   └── a2a_client.py      # Client for calling other agents
│
├── agents/
│   ├── demand_agent/
│   │   ├── agent.py       # Agent implementation
│   │   ├── agent_card.json
│   │   └── skills.py      # Skill handlers
│   │
│   ├── inventory_agent/
│   │   ├── agent.py
│   │   ├── agent_card.json
│   │   └── skills.py
│   │
│   └── pricing_agent/
│       ├── agent.py
│       ├── agent_card.json
│       └── skills.py
│
├── orchestrator/
│   └── main.py            # Demo orchestration
│
└── requirements.txt
```

### Technology Stack

- **Python 3.11+**
- **FastAPI** - HTTP server for each agent
- **Pydantic** - Data validation (A2A message types)
- **HTTPX** - Async HTTP client for agent-to-agent calls
- **uvicorn** - ASGI server

---

## Part 5: Hands-On Implementation 

### Step 1: Define Agent Cards
Each agent publishes its capabilities via `/.well-known/agent.json`

### Step 2: Implement A2A Endpoints
Each agent implements these standard endpoints:
- `GET /.well-known/agent.json` - Agent discovery
- `POST /tasks/send` - Send a task/message
- `GET /tasks/{id}` - Get task status

### Step 3: Implement Skills
Each agent has skill handlers that process incoming tasks

### Step 4: Agent-to-Agent Communication
Agents discover and call each other using the A2A client

### Step 5: Run the Demo
- Start all three agents
- Execute a multi-agent workflow
- Observe the collaboration

---

## Part 6: Key A2A Protocol Features 

### 1. Agent Discovery
Agents expose their capabilities at a well-known endpoint, allowing dynamic discovery.

### 2. Capability Negotiation
Clients can check if an agent supports required skills before sending tasks.

### 3. Streaming Support
Long-running tasks can stream partial results via Server-Sent Events (SSE).

### 4. Artifact Handling
Agents can produce structured outputs (JSON, files) as artifacts.

### 5. Error Handling
Standardized error responses using JSON-RPC error codes.

---

## Discussion Questions

1. How does A2A compare to other agent communication protocols?
2. What security considerations exist for agent-to-agent communication?
3. How would you handle agent versioning and backward compatibility?
4. What monitoring and observability would you add to this system?
5. How could this pattern scale to hundreds of specialized agents?

---

## Additional Resources

- [A2A Protocol Specification](https://github.com/google/A2A)
- [Agent Card Schema](https://google.github.io/A2A/specification/)
- [JSON-RPC 2.0 Specification](https://www.jsonrpc.org/specification)

---

