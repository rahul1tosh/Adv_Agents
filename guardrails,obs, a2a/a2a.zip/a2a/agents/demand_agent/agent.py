"""Demand Forecasting Agent using LangGraph.

This agent consults the Pricing Agent via A2A before generating forecasts.
"""

import sys
sys.path.insert(0, "/Users/abhijithneerkaje/Documents/Code/a2a-demo")

from typing import TypedDict
from langgraph.graph import StateGraph, END
from fastapi import FastAPI
from pydantic import BaseModel

from common.types import (
    AgentCard, Skill, Task, TaskState, TaskRequest, TaskResponse,
    Artifact, SAMPLE_SALES_HISTORY, SAMPLE_PRODUCTS
)
from common.a2a_client import A2AClient

# Pricing Agent URL
PRICING_AGENT_URL = "http://localhost:8002"

# Agent Card
agent_card = AgentCard(
    name="Demand Forecasting Agent",
    description="Predicts product demand using historical sales data, trend analysis, and pricing context",
    url="http://localhost:8001",
    skills=[
        Skill(
            id="forecast_demand",
            name="Forecast Product Demand",
            description="Predict demand for a product over a specified period (consults Pricing Agent)"
        ),
        Skill(
            id="analyze_trends",
            name="Analyze Sales Trends",
            description="Analyze historical sales trends for a product"
        )
    ]
)


# LangGraph State
class DemandState(TypedDict):
    product_id: str
    period_months: int
    historical_data: list[int]
    trend: str
    forecast: int
    confidence: float
    analysis: str
    # Pricing data from A2A call
    recommended_price: float | None
    pricing_strategy: str | None
    a2a_logs: list[str]


# LangGraph Nodes
def load_historical_data(state: DemandState) -> DemandState:
    """Load historical sales data for the product."""
    product_id = state["product_id"]
    historical = SAMPLE_SALES_HISTORY.get(product_id, [100] * 12)
    logs = state.get("a2a_logs", [])
    logs.append(f"Loaded historical data for {product_id} ({len(historical)} months)")
    return {**state, "historical_data": historical, "a2a_logs": logs}


async def consult_pricing_agent(state: DemandState) -> DemandState:
    """Consult the Pricing Agent via A2A to get pricing context."""
    logs = state.get("a2a_logs", [])

    try:
        client = A2AClient(PRICING_AGENT_URL)
        logs.append(f"A2A: Connecting to Pricing Agent at {PRICING_AGENT_URL}")

        # Send task to pricing agent
        task = await client.send_task(
            skill_id="calculate_price",
            data={"product_id": state["product_id"]}
        )

        logs.append(f"A2A: Task {task.id} - State: {task.state}")

        if task.state == TaskState.COMPLETED and task.artifacts:
            pricing_data = task.artifacts[0].data
            logs.append(
                f"A2A: Received pricing - ${pricing_data['recommended_price']:.2f}, "
                f"strategy: {pricing_data['pricing_strategy']}"
            )

            await client.close()
            return {
                **state,
                "recommended_price": pricing_data["recommended_price"],
                "pricing_strategy": pricing_data["pricing_strategy"],
                "a2a_logs": logs
            }

        await client.close()
    except Exception as e:
        logs.append(f"A2A: Error consulting Pricing Agent - {str(e)}")

    # Fallback pricing
    logs.append("Using fallback pricing estimate")
    return {
        **state,
        "recommended_price": 49.99,
        "pricing_strategy": "standard",
        "a2a_logs": logs
    }


def analyze_trend(state: DemandState) -> DemandState:
    """Analyze the sales trend from historical data."""
    data = state["historical_data"]
    logs = state.get("a2a_logs", [])

    if len(data) < 2:
        logs.append("Insufficient data for trend analysis, using stable")
        return {**state, "trend": "stable", "a2a_logs": logs}

    first_half = sum(data[:len(data)//2]) / (len(data)//2)
    second_half = sum(data[len(data)//2:]) / (len(data) - len(data)//2)

    if second_half > first_half * 1.1:
        trend = "increasing"
    elif second_half < first_half * 0.9:
        trend = "decreasing"
    else:
        trend = "stable"

    logs.append(f"Trend analysis complete: {trend}")
    return {**state, "trend": trend, "a2a_logs": logs}


def calculate_forecast(state: DemandState) -> DemandState:
    """Calculate demand forecast based on trend and pricing context."""
    data = state["historical_data"]
    trend = state["trend"]
    period = state["period_months"]
    pricing_strategy = state.get("pricing_strategy", "standard")
    logs = state.get("a2a_logs", [])

    # Simple moving average with trend adjustment
    avg = sum(data[-3:]) / 3 if len(data) >= 3 else sum(data) / len(data)

    # Base growth rate from trend
    if trend == "increasing":
        growth_rate = 1.08
        confidence = 0.75
    elif trend == "decreasing":
        growth_rate = 0.92
        confidence = 0.70
    else:
        growth_rate = 1.0
        confidence = 0.85

    # Adjust forecast based on pricing strategy (from Pricing Agent)
    if pricing_strategy == "premium":
        # Premium pricing typically reduces demand
        growth_rate *= 0.9
        logs.append("Adjusted forecast down for premium pricing strategy")
    elif pricing_strategy == "markdown":
        # Markdown pricing typically increases demand
        growth_rate *= 1.15
        logs.append("Adjusted forecast up for markdown pricing strategy")

    forecast = int(avg * period * growth_rate)
    logs.append(f"Calculated forecast: {forecast} units over {period} months")

    return {**state, "forecast": forecast, "confidence": confidence, "a2a_logs": logs}


def generate_analysis(state: DemandState) -> DemandState:
    """Generate human-readable analysis."""
    product = SAMPLE_PRODUCTS.get(state["product_id"], {})
    product_name = product.get("name", state["product_id"])

    analysis = (
        f"Demand forecast for {product_name}: "
        f"Expected {state['forecast']} units over {state['period_months']} months. "
        f"Trend: {state['trend']}. Confidence: {state['confidence']*100:.0f}%. "
        f"Price context: ${state.get('recommended_price', 0):.2f} ({state.get('pricing_strategy', 'N/A')} strategy)."
    )

    return {**state, "analysis": analysis}


# Build LangGraph
def build_demand_graph():
    graph = StateGraph(DemandState)

    graph.add_node("load_data", load_historical_data)
    graph.add_node("consult_pricing", consult_pricing_agent)
    graph.add_node("analyze_trend", analyze_trend)
    graph.add_node("calculate_forecast", calculate_forecast)
    graph.add_node("generate_analysis", generate_analysis)

    graph.set_entry_point("load_data")
    graph.add_edge("load_data", "consult_pricing")
    graph.add_edge("consult_pricing", "analyze_trend")
    graph.add_edge("analyze_trend", "calculate_forecast")
    graph.add_edge("calculate_forecast", "generate_analysis")
    graph.add_edge("generate_analysis", END)

    return graph.compile()


demand_graph = build_demand_graph()


# FastAPI App
app = FastAPI(title="Demand Forecasting Agent")


@app.get("/.well-known/agent.json")
async def get_agent_card():
    """A2A: Agent discovery endpoint."""
    return agent_card.model_dump()


class ForecastRequest(BaseModel):
    product_id: str
    period_months: int = 3


@app.post("/forecast")
async def forecast_demand(request: ForecastRequest):
    """Direct API for demand forecasting."""
    result = await demand_graph.ainvoke({
        "product_id": request.product_id,
        "period_months": request.period_months,
        "historical_data": [],
        "trend": "",
        "forecast": 0,
        "confidence": 0.0,
        "analysis": "",
        "recommended_price": None,
        "pricing_strategy": None,
        "a2a_logs": []
    })
    return {
        "product_id": request.product_id,
        "forecast": result["forecast"],
        "trend": result["trend"],
        "confidence": result["confidence"],
        "recommended_price": result["recommended_price"],
        "pricing_strategy": result["pricing_strategy"],
        "analysis": result["analysis"],
        "a2a_logs": result["a2a_logs"]
    }


@app.post("/tasks/send")
async def send_task(request: TaskRequest):
    """A2A: Task execution endpoint."""
    task = Task(state=TaskState.WORKING)

    try:
        # Extract parameters from message
        product_id = "SKU-001"
        period_months = 3

        for part in request.message.parts:
            if part.data:
                product_id = part.data.get("product_id", product_id)
                period_months = part.data.get("period_months", period_months)
            elif part.text:
                # Parse product ID from text
                for sku in SAMPLE_PRODUCTS.keys():
                    if sku in part.text.upper():
                        product_id = sku
                        break

        # Run the graph (async)
        result = await demand_graph.ainvoke({
            "product_id": product_id,
            "period_months": period_months,
            "historical_data": [],
            "trend": "",
            "forecast": 0,
            "confidence": 0.0,
            "analysis": "",
            "recommended_price": None,
            "pricing_strategy": None,
            "a2a_logs": []
        })

        task.state = TaskState.COMPLETED
        task.artifacts = [
            Artifact(
                name="demand_forecast",
                data={
                    "product_id": product_id,
                    "forecast": result["forecast"],
                    "trend": result["trend"],
                    "confidence": result["confidence"],
                    "period_months": period_months,
                    "recommended_price": result["recommended_price"],
                    "pricing_strategy": result["pricing_strategy"],
                    "a2a_logs": result["a2a_logs"]
                }
            )
        ]
    except Exception as e:
        task.state = TaskState.FAILED
        task.error = str(e)

    return TaskResponse(task=task)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
