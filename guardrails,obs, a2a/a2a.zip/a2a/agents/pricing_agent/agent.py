"""Store Pricing Agent using LangGraph."""

import sys
sys.path.insert(0, "/Users/abhijithneerkaje/Documents/Code/a2a-demo")

from typing import TypedDict
from langgraph.graph import StateGraph, END
from fastapi import FastAPI
from pydantic import BaseModel

from common.types import (
    AgentCard, Skill, Task, TaskState, TaskRequest, TaskResponse,
    Artifact, SAMPLE_PRODUCTS, SAMPLE_INVENTORY
)

# Agent Card
agent_card = AgentCard(
    name="Store Pricing Agent",
    description="Calculates optimal prices based on costs, margins, and market conditions",
    url="http://localhost:8002",
    skills=[
        Skill(
            id="calculate_price",
            name="Calculate Optimal Price",
            description="Determine the optimal selling price for a product"
        ),
        Skill(
            id="analyze_margins",
            name="Analyze Profit Margins",
            description="Analyze profit margins for a product"
        ),
        Skill(
            id="suggest_markdown",
            name="Suggest Markdown",
            description="Suggest markdown prices for slow-moving inventory"
        )
    ]
)


# LangGraph State
class PricingState(TypedDict):
    product_id: str
    cost: float
    current_stock: int
    demand_forecast: int | None
    target_margin: float
    recommended_price: float
    margin_percent: float
    pricing_strategy: str
    analysis: str


# LangGraph Nodes
def load_product_data(state: PricingState) -> PricingState:
    """Load product cost and inventory data."""
    product_id = state["product_id"]
    product = SAMPLE_PRODUCTS.get(product_id, {"cost": 50.0})
    inventory = SAMPLE_INVENTORY.get(product_id, {"current_stock": 100})

    return {
        **state,
        "cost": product.get("cost", 50.0),
        "current_stock": inventory.get("current_stock", 100)
    }


def determine_strategy(state: PricingState) -> PricingState:
    """Determine pricing strategy based on inventory and demand."""
    stock = state["current_stock"]
    demand = state.get("demand_forecast") or 100

    # High stock, low demand -> markdown
    if stock > demand * 1.5:
        strategy = "markdown"
        target_margin = 0.15
    # Low stock, high demand -> premium
    elif stock < demand * 0.5:
        strategy = "premium"
        target_margin = 0.40
    # Balanced -> standard
    else:
        strategy = "standard"
        target_margin = 0.25

    return {**state, "pricing_strategy": strategy, "target_margin": target_margin}


def calculate_price(state: PricingState) -> PricingState:
    """Calculate the recommended price."""
    cost = state["cost"]
    margin = state["target_margin"]

    # Price = Cost / (1 - margin)
    price = cost / (1 - margin)

    # Round to .99 pricing
    price = round(price) - 0.01

    actual_margin = (price - cost) / price

    return {
        **state,
        "recommended_price": price,
        "margin_percent": actual_margin * 100
    }


def generate_pricing_analysis(state: PricingState) -> PricingState:
    """Generate pricing recommendation analysis."""
    product = SAMPLE_PRODUCTS.get(state["product_id"], {})
    product_name = product.get("name", state["product_id"])

    analysis = (
        f"Pricing for {product_name}: "
        f"Recommended ${state['recommended_price']:.2f} "
        f"(cost: ${state['cost']:.2f}, margin: {state['margin_percent']:.1f}%). "
        f"Strategy: {state['pricing_strategy']}."
    )

    return {**state, "analysis": analysis}


# Build LangGraph
def build_pricing_graph():
    graph = StateGraph(PricingState)

    graph.add_node("load_data", load_product_data)
    graph.add_node("determine_strategy", determine_strategy)
    graph.add_node("calculate_price", calculate_price)
    graph.add_node("generate_analysis", generate_pricing_analysis)

    graph.set_entry_point("load_data")
    graph.add_edge("load_data", "determine_strategy")
    graph.add_edge("determine_strategy", "calculate_price")
    graph.add_edge("calculate_price", "generate_analysis")
    graph.add_edge("generate_analysis", END)

    return graph.compile()


pricing_graph = build_pricing_graph()


# FastAPI App
app = FastAPI(title="Store Pricing Agent")


@app.get("/.well-known/agent.json")
async def get_agent_card():
    """A2A: Agent discovery endpoint."""
    return agent_card.model_dump()


class PricingRequest(BaseModel):
    product_id: str
    demand_forecast: int | None = None


@app.post("/price")
async def get_price(request: PricingRequest):
    """Direct API for pricing calculation."""
    result = pricing_graph.invoke({
        "product_id": request.product_id,
        "cost": 0.0,
        "current_stock": 0,
        "demand_forecast": request.demand_forecast,
        "target_margin": 0.0,
        "recommended_price": 0.0,
        "margin_percent": 0.0,
        "pricing_strategy": "",
        "analysis": ""
    })
    return {
        "product_id": request.product_id,
        "recommended_price": result["recommended_price"],
        "margin_percent": result["margin_percent"],
        "pricing_strategy": result["pricing_strategy"],
        "analysis": result["analysis"]
    }


@app.post("/tasks/send")
async def send_task(request: TaskRequest):
    """A2A: Task execution endpoint."""
    task = Task(state=TaskState.WORKING)

    try:
        # Extract parameters from message
        product_id = "SKU-001"
        demand_forecast = None

        for part in request.message.parts:
            if part.data:
                product_id = part.data.get("product_id", product_id)
                demand_forecast = part.data.get("demand_forecast")
            elif part.text:
                for sku in SAMPLE_PRODUCTS.keys():
                    if sku in part.text.upper():
                        product_id = sku
                        break

        # Run the graph
        result = pricing_graph.invoke({
            "product_id": product_id,
            "cost": 0.0,
            "current_stock": 0,
            "demand_forecast": demand_forecast,
            "target_margin": 0.0,
            "recommended_price": 0.0,
            "margin_percent": 0.0,
            "pricing_strategy": "",
            "analysis": ""
        })

        task.state = TaskState.COMPLETED
        task.artifacts = [
            Artifact(
                name="pricing_recommendation",
                data={
                    "product_id": product_id,
                    "recommended_price": result["recommended_price"],
                    "cost": result["cost"],
                    "margin_percent": result["margin_percent"],
                    "pricing_strategy": result["pricing_strategy"]
                }
            )
        ]
    except Exception as e:
        task.state = TaskState.FAILED
        task.error = str(e)

    return TaskResponse(task=task)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)
