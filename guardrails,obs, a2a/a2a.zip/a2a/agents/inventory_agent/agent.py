"""Store Inventory Planning Agent using LangGraph.

This agent consults the Demand Agent via A2A, which in turn consults the Pricing Agent.
Flow: Inventory Agent -> Demand Agent -> Pricing Agent
"""

import sys
sys.path.insert(0, "/Users/abhijithneerkaje/Documents/Code/a2a-demo")

from typing import TypedDict
from langgraph.graph import StateGraph, END
from fastapi import FastAPI
from pydantic import BaseModel

from common.types import (
    AgentCard, Skill, Task, TaskState, TaskRequest, TaskResponse,
    Artifact, SAMPLE_PRODUCTS, SAMPLE_INVENTORY
)
from common.a2a_client import A2AClient

# Agent URL - Only need Demand Agent (it calls Pricing Agent internally)
DEMAND_AGENT_URL = "http://localhost:8001"

# Agent Card
agent_card = AgentCard(
    name="Store Inventory Planning Agent",
    description="Plans inventory levels and reorder quantities by consulting the demand forecasting agent",
    url="http://localhost:8003",
    skills=[
        Skill(
            id="plan_inventory",
            name="Plan Inventory",
            description="Create a comprehensive inventory plan for a product"
        ),
        Skill(
            id="check_reorder",
            name="Check Reorder Status",
            description="Check if a product needs reordering"
        ),
        Skill(
            id="get_inventory_status",
            name="Get Inventory Status",
            description="Get current inventory status for all products"
        )
    ]
)


# LangGraph State
class InventoryState(TypedDict):
    product_id: str
    current_stock: int
    warehouse_capacity: int
    reorder_point: int
    demand_forecast: int | None
    demand_trend: str | None
    recommended_price: float | None
    pricing_strategy: str | None
    reorder_quantity: int
    reorder_needed: bool
    action: str
    analysis: str
    a2a_logs: list[str]


# LangGraph Nodes
def load_inventory_data(state: InventoryState) -> InventoryState:
    """Load current inventory data."""
    product_id = state["product_id"]
    inventory = SAMPLE_INVENTORY.get(product_id, {
        "current_stock": 100,
        "warehouse_capacity": 500,
        "reorder_point": 50
    })

    return {
        **state,
        "current_stock": inventory["current_stock"],
        "warehouse_capacity": inventory["warehouse_capacity"],
        "reorder_point": inventory["reorder_point"],
        "a2a_logs": state.get("a2a_logs", []) + [f"Loaded inventory for {product_id}"]
    }


async def consult_demand_agent(state: InventoryState) -> InventoryState:
    """Consult the Demand Forecasting Agent via A2A.

    The Demand Agent will internally consult the Pricing Agent and return
    both forecast and pricing information.
    """
    logs = state.get("a2a_logs", [])

    try:
        client = A2AClient(DEMAND_AGENT_URL)
        logs.append(f"A2A: Connecting to Demand Agent at {DEMAND_AGENT_URL}")

        # Send task to demand agent
        task = await client.send_task(
            skill_id="forecast_demand",
            data={"product_id": state["product_id"], "period_months": 3}
        )

        logs.append(f"A2A: Task {task.id} - State: {task.state}")

        if task.state == TaskState.COMPLETED and task.artifacts:
            forecast_data = task.artifacts[0].data

            # Extract demand forecast
            logs.append(
                f"A2A: Received forecast - {forecast_data['forecast']} units, "
                f"trend: {forecast_data['trend']}"
            )

            # Extract pricing info (passed through from Demand Agent's call to Pricing Agent)
            recommended_price = forecast_data.get("recommended_price")
            pricing_strategy = forecast_data.get("pricing_strategy")

            if recommended_price and pricing_strategy:
                logs.append(
                    f"A2A: Received pricing (via Demand Agent) - ${recommended_price:.2f}, "
                    f"strategy: {pricing_strategy}"
                )

            # Include nested A2A logs from Demand Agent
            nested_logs = forecast_data.get("a2a_logs", [])
            for nested_log in nested_logs:
                logs.append(f"  [Demand Agent] {nested_log}")

            await client.close()
            return {
                **state,
                "demand_forecast": forecast_data["forecast"],
                "demand_trend": forecast_data["trend"],
                "recommended_price": recommended_price,
                "pricing_strategy": pricing_strategy,
                "a2a_logs": logs
            }

        await client.close()
    except Exception as e:
        logs.append(f"A2A: Error consulting Demand Agent - {str(e)}")

    # Fallback: estimate demand and pricing
    logs.append("Using fallback demand and pricing estimates")
    return {
        **state,
        "demand_forecast": state["current_stock"],
        "demand_trend": "stable",
        "recommended_price": 49.99,
        "pricing_strategy": "standard",
        "a2a_logs": logs
    }


def calculate_reorder(state: InventoryState) -> InventoryState:
    """Calculate reorder quantity based on all inputs."""
    current = state["current_stock"]
    capacity = state["warehouse_capacity"]
    reorder_point = state["reorder_point"]
    demand = state.get("demand_forecast") or 100
    trend = state.get("demand_trend") or "stable"

    # Check if reorder needed
    reorder_needed = current <= reorder_point

    if reorder_needed:
        # Calculate order quantity
        # Target: enough stock for 2x demand period with buffer
        target_stock = min(demand * 2, capacity * 0.8)

        # Adjust for trend
        if trend == "increasing":
            target_stock *= 1.2
        elif trend == "decreasing":
            target_stock *= 0.8

        reorder_quantity = max(0, int(target_stock - current))

        # Don't exceed capacity
        reorder_quantity = min(reorder_quantity, capacity - current)
    else:
        reorder_quantity = 0

    return {
        **state,
        "reorder_needed": reorder_needed,
        "reorder_quantity": reorder_quantity
    }


def determine_action(state: InventoryState) -> InventoryState:
    """Determine the recommended action."""
    if not state["reorder_needed"]:
        action = "HOLD - Stock levels adequate"
    elif state["reorder_quantity"] > 0:
        action = f"REORDER - Order {state['reorder_quantity']} units"
    else:
        action = "MONITOR - Near capacity, watch demand"

    return {**state, "action": action}


def generate_inventory_analysis(state: InventoryState) -> InventoryState:
    """Generate comprehensive inventory analysis."""
    product = SAMPLE_PRODUCTS.get(state["product_id"], {})
    product_name = product.get("name", state["product_id"])

    analysis_parts = [
        f"📦 INVENTORY PLAN FOR {product_name.upper()}",
        f"",
        f"Current Status:",
        f"  • Stock: {state['current_stock']} units",
        f"  • Capacity: {state['warehouse_capacity']} units",
        f"  • Reorder Point: {state['reorder_point']} units",
        f"",
        f"Intelligence from Partner Agents:",
        f"  • Demand Forecast: {state.get('demand_forecast', 'N/A')} units (3 months)",
        f"  • Demand Trend: {state.get('demand_trend', 'N/A')}",
        f"  • Recommended Price: ${state.get('recommended_price', 0):.2f}",
        f"  • Pricing Strategy: {state.get('pricing_strategy', 'N/A')}",
        f"",
        f"Recommendation:",
        f"  {state['action']}",
        f"",
        f"A2A Communication Log:",
    ]

    for log in state.get("a2a_logs", []):
        analysis_parts.append(f"  → {log}")

    return {**state, "analysis": "\n".join(analysis_parts)}


# Build LangGraph - simplified flow (only calls Demand Agent)
def build_inventory_graph():
    graph = StateGraph(InventoryState)

    graph.add_node("load_inventory", load_inventory_data)
    graph.add_node("consult_demand", consult_demand_agent)
    graph.add_node("calculate_reorder", calculate_reorder)
    graph.add_node("determine_action", determine_action)
    graph.add_node("generate_analysis", generate_inventory_analysis)

    graph.set_entry_point("load_inventory")
    graph.add_edge("load_inventory", "consult_demand")
    graph.add_edge("consult_demand", "calculate_reorder")
    graph.add_edge("calculate_reorder", "determine_action")
    graph.add_edge("determine_action", "generate_analysis")
    graph.add_edge("generate_analysis", END)

    return graph.compile()


inventory_graph = build_inventory_graph()


# FastAPI App
app = FastAPI(title="Store Inventory Planning Agent")


@app.get("/.well-known/agent.json")
async def get_agent_card():
    """A2A: Agent discovery endpoint."""
    return agent_card.model_dump()


@app.get("/inventory/status")
async def get_all_inventory_status():
    """Get status of all products."""
    status = []
    for sku, inv in SAMPLE_INVENTORY.items():
        product = SAMPLE_PRODUCTS.get(sku, {})
        needs_reorder = inv["current_stock"] <= inv["reorder_point"]
        status.append({
            "product_id": sku,
            "name": product.get("name", sku),
            "current_stock": inv["current_stock"],
            "reorder_point": inv["reorder_point"],
            "needs_reorder": needs_reorder,
            "status": "⚠️ LOW" if needs_reorder else "✓ OK"
        })
    return {"products": status}


class PlanRequest(BaseModel):
    product_id: str


@app.post("/plan")
async def plan_inventory(request: PlanRequest):
    """Create an inventory plan for a product."""
    initial_state = {
        "product_id": request.product_id,
        "current_stock": 0,
        "warehouse_capacity": 0,
        "reorder_point": 0,
        "demand_forecast": None,
        "demand_trend": None,
        "recommended_price": None,
        "pricing_strategy": None,
        "reorder_quantity": 0,
        "reorder_needed": False,
        "action": "",
        "analysis": "",
        "a2a_logs": []
    }

    result = await inventory_graph.ainvoke(initial_state)

    return {
        "product_id": request.product_id,
        "reorder_needed": result["reorder_needed"],
        "reorder_quantity": result["reorder_quantity"],
        "action": result["action"],
        "analysis": result["analysis"]
    }


@app.post("/tasks/send")
async def send_task(request: TaskRequest):
    """A2A: Task execution endpoint."""
    task = Task(state=TaskState.WORKING)

    try:
        # Extract product_id
        product_id = "SKU-001"
        for part in request.message.parts:
            if part.data:
                product_id = part.data.get("product_id", product_id)
            elif part.text:
                for sku in SAMPLE_PRODUCTS.keys():
                    if sku in part.text.upper():
                        product_id = sku
                        break

        initial_state = {
            "product_id": product_id,
            "current_stock": 0,
            "warehouse_capacity": 0,
            "reorder_point": 0,
            "demand_forecast": None,
            "demand_trend": None,
            "recommended_price": None,
            "pricing_strategy": None,
            "reorder_quantity": 0,
            "reorder_needed": False,
            "action": "",
            "analysis": "",
            "a2a_logs": []
        }

        result = await inventory_graph.ainvoke(initial_state)

        task.state = TaskState.COMPLETED
        task.artifacts = [
            Artifact(
                name="inventory_plan",
                data={
                    "product_id": product_id,
                    "current_stock": result["current_stock"],
                    "reorder_needed": result["reorder_needed"],
                    "reorder_quantity": result["reorder_quantity"],
                    "action": result["action"],
                    "demand_forecast": result["demand_forecast"],
                    "recommended_price": result["recommended_price"]
                }
            )
        ]
    except Exception as e:
        task.state = TaskState.FAILED
        task.error = str(e)

    return TaskResponse(task=task)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8003)
