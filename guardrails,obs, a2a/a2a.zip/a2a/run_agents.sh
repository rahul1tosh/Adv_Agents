#!/bin/bash

# A2A Retail Multi-Agent Demo - Startup Script

echo "🚀 Starting A2A Retail Multi-Agent System..."
echo ""

# Kill any existing processes on the ports
echo "Cleaning up existing processes..."
lsof -ti:8001 | xargs kill -9 2>/dev/null
lsof -ti:8002 | xargs kill -9 2>/dev/null
lsof -ti:8003 | xargs kill -9 2>/dev/null
lsof -ti:7860 | xargs kill -9 2>/dev/null

sleep 1

# Start agents in background
echo "Starting Demand Forecasting Agent on port 8001..."
python agents/demand_agent/agent.py &
DEMAND_PID=$!

echo "Starting Pricing Agent on port 8002..."
python agents/pricing_agent/agent.py &
PRICING_PID=$!

echo "Starting Inventory Planning Agent on port 8003..."
python agents/inventory_agent/agent.py &
INVENTORY_PID=$!

# Wait for agents to start
echo ""
echo "Waiting for agents to initialize..."
sleep 3

# Verify agents are running
echo ""
echo "Checking agent status..."
echo ""

curl -s http://localhost:8001/.well-known/agent.json > /dev/null && echo "✅ Demand Agent running" || echo "❌ Demand Agent failed"
curl -s http://localhost:8002/.well-known/agent.json > /dev/null && echo "✅ Pricing Agent running" || echo "❌ Pricing Agent failed"
curl -s http://localhost:8003/.well-known/agent.json > /dev/null && echo "✅ Inventory Agent running" || echo "❌ Inventory Agent failed"

echo ""
echo "Starting Gradio frontend on port 7860..."
python frontend/app.py &
FRONTEND_PID=$!

echo ""
echo "========================================="
echo "  A2A Multi-Agent System is Running!"
echo "========================================="
echo ""
echo "Agent Endpoints:"
echo "  📊 Demand Agent:    http://localhost:8001"
echo "  💰 Pricing Agent:   http://localhost:8002"
echo "  📦 Inventory Agent: http://localhost:8003"
echo ""
echo "Frontend:"
echo "  🌐 Gradio UI:       http://localhost:7860"
echo ""
echo "Agent Cards:"
echo "  http://localhost:8001/.well-known/agent.json"
echo "  http://localhost:8002/.well-known/agent.json"
echo "  http://localhost:8003/.well-known/agent.json"
echo ""
echo "Press Ctrl+C to stop all services"
echo ""

# Handle cleanup on exit
cleanup() {
    echo ""
    echo "Shutting down agents..."
    kill $DEMAND_PID $PRICING_PID $INVENTORY_PID $FRONTEND_PID 2>/dev/null
    exit 0
}

trap cleanup SIGINT SIGTERM

# Wait for all background processes
wait
