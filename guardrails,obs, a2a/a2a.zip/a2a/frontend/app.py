"""Gradio Frontend for A2A Retail Multi-Agent Demo."""

import sys
sys.path.insert(0, "/Users/abhijithneerkaje/Documents/Code/a2a-demo")

import gradio as gr
import httpx
import asyncio
import re
from typing import Optional

# Agent URLs
DEMAND_AGENT_URL = "http://localhost:8001"
PRICING_AGENT_URL = "http://localhost:8002"
INVENTORY_AGENT_URL = "http://localhost:8003"

# Product options
PRODUCTS = {
    "SKU-001": "Wireless Headphones",
    "SKU-002": "Running Shoes",
    "SKU-003": "Coffee Maker",
    "SKU-004": "Yoga Mat",
    "SKU-005": "Backpack"
}

# Reverse lookup: product name -> SKU
PRODUCT_NAMES = {v.lower(): k for k, v in PRODUCTS.items()}


def extract_product_id(query: str) -> Optional[str]:
    """Extract product ID from natural language query."""
    query_upper = query.upper()
    query_lower = query.lower()

    # Check for SKU pattern
    for sku in PRODUCTS.keys():
        if sku in query_upper:
            return sku

    # Check for product names
    for name, sku in PRODUCT_NAMES.items():
        if name in query_lower:
            return sku

    # Partial matches
    partial_matches = {
        "headphone": "SKU-001",
        "shoe": "SKU-002",
        "coffee": "SKU-003",
        "yoga": "SKU-004",
        "backpack": "SKU-005",
        "bag": "SKU-005",
    }
    for keyword, sku in partial_matches.items():
        if keyword in query_lower:
            return sku

    return None


def detect_intent(query: str) -> str:
    """Detect the user's intent from natural language."""
    query_lower = query.lower()

    # Inventory planning intents
    inventory_keywords = [
        "inventory", "plan", "reorder", "stock", "restock",
        "should we order", "need to order", "running low"
    ]
    if any(kw in query_lower for kw in inventory_keywords):
        return "inventory"

    # Status/overview intents
    status_keywords = ["status", "all products", "overview", "list", "show all"]
    if any(kw in query_lower for kw in status_keywords):
        return "status"

    # Demand forecast intents
    demand_keywords = ["demand", "forecast", "predict", "sales", "trend"]
    if any(kw in query_lower for kw in demand_keywords):
        return "demand"

    # Pricing intents
    pricing_keywords = ["price", "pricing", "cost", "margin", "markdown"]
    if any(kw in query_lower for kw in pricing_keywords):
        return "pricing"

    # Default to inventory planning
    return "inventory"


async def check_agent_status(url: str) -> tuple[bool, str]:
    """Check if an agent is running."""
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            response = await client.get(f"{url}/.well-known/agent.json")
            if response.status_code == 200:
                data = response.json()
                return True, data.get("name", "Unknown Agent")
    except:
        pass
    return False, "Not Running"


async def get_agent_statuses():
    """Get status of all agents."""
    demand_ok, demand_name = await check_agent_status(DEMAND_AGENT_URL)
    pricing_ok, pricing_name = await check_agent_status(PRICING_AGENT_URL)
    inventory_ok, inventory_name = await check_agent_status(INVENTORY_AGENT_URL)

    status_lines = [
        f"{'✅' if demand_ok else '❌'} Demand Agent (8001): {demand_name}",
        f"{'✅' if pricing_ok else '❌'} Pricing Agent (8002): {pricing_name}",
        f"{'✅' if inventory_ok else '❌'} Inventory Agent (8003): {inventory_name}",
    ]
    return "\n".join(status_lines)


async def call_demand_forecast(product_id: str, months: int = 3):
    """Call the demand forecasting agent."""
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.post(
                f"{DEMAND_AGENT_URL}/forecast",
                json={"product_id": product_id, "period_months": months}
            )
            if response.status_code == 200:
                data = response.json()
                output = f"""📊 DEMAND FORECAST

Product: {PRODUCTS.get(product_id, product_id)}
Period: {months} months

Forecast: {data['forecast']} units
Trend: {data['trend'].upper()}
Confidence: {data['confidence']*100:.0f}%
Price Context: ${data.get('recommended_price', 0):.2f} ({data.get('pricing_strategy', 'N/A')} strategy)

{data['analysis']}

A2A Communication Log:"""
                for log in data.get('a2a_logs', []):
                    output += f"\n  → {log}"
                return output
            return f"Error: {response.status_code}"
    except Exception as e:
        return f"Error connecting to Demand Agent: {str(e)}"


async def call_pricing_agent(product_id: str, demand_forecast: Optional[int] = None):
    """Call the pricing agent."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            payload = {"product_id": product_id}
            if demand_forecast:
                payload["demand_forecast"] = demand_forecast

            response = await client.post(
                f"{PRICING_AGENT_URL}/price",
                json=payload
            )
            if response.status_code == 200:
                data = response.json()
                return f"""💰 PRICING RECOMMENDATION

Product: {PRODUCTS.get(product_id, product_id)}

Recommended Price: ${data['recommended_price']:.2f}
Profit Margin: {data['margin_percent']:.1f}%
Strategy: {data['pricing_strategy'].upper()}

{data['analysis']}"""
            return f"Error: {response.status_code}"
    except Exception as e:
        return f"Error connecting to Pricing Agent: {str(e)}"


async def call_inventory_plan(product_id: str):
    """Call the inventory planning agent."""
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{INVENTORY_AGENT_URL}/plan",
                json={"product_id": product_id}
            )
            if response.status_code == 200:
                data = response.json()
                return data['analysis']
            return f"Error: {response.status_code}"
    except Exception as e:
        return f"Error connecting to Inventory Agent: {str(e)}"


async def get_inventory_status():
    """Get inventory status for all products."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f"{INVENTORY_AGENT_URL}/inventory/status")
            if response.status_code == 200:
                data = response.json()
                lines = ["📋 INVENTORY STATUS\n"]
                for product in data['products']:
                    lines.append(
                        f"{product['status']} {product['name']} ({product['product_id']}): "
                        f"{product['current_stock']} units"
                    )
                return "\n".join(lines)
            return f"Error: {response.status_code}"
    except Exception as e:
        return f"Error connecting to Inventory Agent: {str(e)}"


async def process_natural_language_query(query: str) -> str:
    """Process a natural language query and route to appropriate agent."""
    if not query.strip():
        return "Please enter a question. Try: 'Create inventory plan for SKU-001'"

    intent = detect_intent(query)
    product_id = extract_product_id(query)

    # Handle status queries (no product needed)
    if intent == "status":
        return await get_inventory_status()

    # For other intents, we need a product
    if not product_id:
        return f"""🤔 I couldn't identify a product in your query.

Please specify a product using:
- SKU codes: SKU-001, SKU-002, SKU-003, SKU-004, SKU-005
- Product names: Wireless Headphones, Running Shoes, Coffee Maker, Yoga Mat, Backpack

Example: "Create inventory plan for SKU-001"
Example: "What's the demand forecast for Running Shoes?"
Example: "Get pricing for Coffee Maker"
"""

    # Route to appropriate agent
    if intent == "inventory":
        return await call_inventory_plan(product_id)
    elif intent == "demand":
        return await call_demand_forecast(product_id)
    elif intent == "pricing":
        return await call_pricing_agent(product_id)
    else:
        return await call_inventory_plan(product_id)


# Sync wrapper for Gradio
def handle_query(query: str) -> str:
    return asyncio.run(process_natural_language_query(query))


def refresh_status():
    return asyncio.run(get_agent_statuses())


# Build Gradio Interface
with gr.Blocks(title="A2A Retail Multi-Agent Demo", theme=gr.themes.Soft()) as demo:
    gr.Markdown("""
    # 🏪 A2A Protocol Demo: Retail Multi-Agent System

    Ask questions in **natural language** to interact with the multi-agent system.
    """)

    with gr.Row():
        with gr.Column(scale=3):
            query_input = gr.Textbox(
                label="Ask a question",
                placeholder="e.g., Create inventory plan for SKU-001",
                lines=2
            )
            with gr.Row():
                submit_btn = gr.Button("🚀 Submit", variant="primary")
                clear_btn = gr.Button("🗑️ Clear")

        with gr.Column(scale=1):
            gr.Markdown("### Agent Status")
            status_output = gr.Textbox(label="", lines=4, interactive=False)
            refresh_btn = gr.Button("🔄 Refresh", size="sm")

    response_output = gr.Textbox(
        label="Response",
        lines=25,
        interactive=False
    )

    # Example queries
    gr.Markdown("### 💡 Try these queries:")
    with gr.Row():
        ex1 = gr.Button("Create inventory plan for SKU-001", size="sm")
        ex2 = gr.Button("Should we reorder Running Shoes?", size="sm")
        ex3 = gr.Button("Show inventory status", size="sm")
    with gr.Row():
        ex4 = gr.Button("Forecast demand for Coffee Maker", size="sm")
        ex5 = gr.Button("Get pricing for Yoga Mat", size="sm")
        ex6 = gr.Button("Plan inventory for SKU-004", size="sm")

    gr.Markdown("""
    ---
    ### How It Works (Chained A2A Calls)

    ```
    Your Question → Inventory Agent ──A2A──► Demand Agent ──A2A──► Pricing Agent
                                                                         │
                                                           price context │
                                                                         ▼
                  ◄── Inventory Plan ◄── forecast + pricing ◄────────────┘
    ```

    **Available Products:**
    | SKU | Product |
    |-----|---------|
    | SKU-001 | Wireless Headphones |
    | SKU-002 | Running Shoes |
    | SKU-003 | Coffee Maker |
    | SKU-004 | Yoga Mat |
    | SKU-005 | Backpack |
    """)

    # Event handlers
    submit_btn.click(fn=handle_query, inputs=[query_input], outputs=[response_output])
    query_input.submit(fn=handle_query, inputs=[query_input], outputs=[response_output])
    clear_btn.click(fn=lambda: ("", ""), outputs=[query_input, response_output])
    refresh_btn.click(fn=refresh_status, outputs=status_output)

    # Example button handlers
    ex1.click(fn=lambda: "Create inventory plan for SKU-001", outputs=query_input)
    ex2.click(fn=lambda: "Should we reorder Running Shoes?", outputs=query_input)
    ex3.click(fn=lambda: "Show inventory status", outputs=query_input)
    ex4.click(fn=lambda: "Forecast demand for Coffee Maker", outputs=query_input)
    ex5.click(fn=lambda: "Get pricing for Yoga Mat", outputs=query_input)
    ex6.click(fn=lambda: "Plan inventory for SKU-004", outputs=query_input)


if __name__ == "__main__":
    demo.launch(server_port=7860)
