"""A2A Protocol Types - Simplified for teaching purposes."""

from enum import Enum
from typing import Any
from pydantic import BaseModel, Field
import uuid


class TaskState(str, Enum):
    SUBMITTED = "submitted"
    WORKING = "working"
    COMPLETED = "completed"
    FAILED = "failed"


class Skill(BaseModel):
    """A capability that an agent can perform."""
    id: str
    name: str
    description: str
    input_modes: list[str] = ["text/plain", "application/json"]
    output_modes: list[str] = ["application/json"]


class AgentCard(BaseModel):
    """Describes an agent's identity and capabilities."""
    name: str
    description: str
    url: str
    version: str = "1.0.0"
    skills: list[Skill] = []


class MessagePart(BaseModel):
    """A part of a message (text or data)."""
    type: str = "text"
    text: str | None = None
    data: dict[str, Any] | None = None


class Message(BaseModel):
    """A message in the A2A protocol."""
    role: str = "user"
    parts: list[MessagePart]


class Artifact(BaseModel):
    """Output produced by an agent."""
    name: str
    type: str = "application/json"
    data: dict[str, Any]


class Task(BaseModel):
    """A unit of work in the A2A protocol."""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    state: TaskState = TaskState.SUBMITTED
    message: Message | None = None
    artifacts: list[Artifact] = []
    error: str | None = None


class TaskRequest(BaseModel):
    """Request to create or update a task."""
    skill_id: str
    message: Message


class TaskResponse(BaseModel):
    """Response from a task operation."""
    task: Task


# Sample product data for the demo
SAMPLE_PRODUCTS = {
    "SKU-001": {"name": "Wireless Headphones", "cost": 45.00, "category": "Electronics"},
    "SKU-002": {"name": "Running Shoes", "cost": 65.00, "category": "Footwear"},
    "SKU-003": {"name": "Coffee Maker", "cost": 35.00, "category": "Appliances"},
    "SKU-004": {"name": "Yoga Mat", "cost": 15.00, "category": "Fitness"},
    "SKU-005": {"name": "Backpack", "cost": 25.00, "category": "Accessories"},
}

# Sample inventory data
SAMPLE_INVENTORY = {
    "SKU-001": {"current_stock": 150, "warehouse_capacity": 500, "reorder_point": 100},
    "SKU-002": {"current_stock": 45, "warehouse_capacity": 300, "reorder_point": 50},
    "SKU-003": {"current_stock": 200, "warehouse_capacity": 400, "reorder_point": 80},
    "SKU-004": {"current_stock": 30, "warehouse_capacity": 200, "reorder_point": 40},
    "SKU-005": {"current_stock": 75, "warehouse_capacity": 250, "reorder_point": 60},
}

# Sample historical sales for forecasting
SAMPLE_SALES_HISTORY = {
    "SKU-001": [120, 135, 150, 140, 160, 155, 170, 165, 180, 175, 190, 185],
    "SKU-002": [80, 75, 90, 95, 100, 110, 105, 115, 120, 125, 130, 140],
    "SKU-003": [60, 65, 70, 55, 75, 80, 70, 85, 90, 80, 95, 100],
    "SKU-004": [40, 45, 50, 55, 60, 70, 65, 75, 80, 85, 90, 95],
    "SKU-005": [50, 55, 45, 60, 55, 65, 70, 60, 75, 70, 80, 85],
}
