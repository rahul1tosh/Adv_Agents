"""A2A Client for agent-to-agent communication."""

import httpx
from .types import AgentCard, Task, TaskRequest, Message, MessagePart, TaskResponse


class A2AClient:
    """Client for communicating with other A2A agents."""

    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")
        self.client = httpx.AsyncClient(timeout=30.0)

    async def get_agent_card(self) -> AgentCard:
        """Discover agent capabilities."""
        response = await self.client.get(f"{self.base_url}/.well-known/agent.json")
        response.raise_for_status()
        return AgentCard(**response.json())

    async def send_task(self, skill_id: str, text: str | None = None, data: dict | None = None) -> Task:
        """Send a task to the agent."""
        parts = []
        if text:
            parts.append(MessagePart(type="text", text=text))
        if data:
            parts.append(MessagePart(type="data", data=data))

        request = TaskRequest(
            skill_id=skill_id,
            message=Message(role="user", parts=parts)
        )

        response = await self.client.post(
            f"{self.base_url}/tasks/send",
            json=request.model_dump()
        )
        response.raise_for_status()
        task_response = TaskResponse(**response.json())
        return task_response.task

    async def get_task(self, task_id: str) -> Task:
        """Get task status."""
        response = await self.client.get(f"{self.base_url}/tasks/{task_id}")
        response.raise_for_status()
        return Task(**response.json())

    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()
