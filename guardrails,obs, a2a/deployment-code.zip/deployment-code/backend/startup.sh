#!/bin/bash
set -e

echo "==> Installing backend dependencies..."
pip install -r /home/site/wwwroot/backend/requirements.txt

echo "==> Starting Inventory Planning Agent backend..."
cd /home/site/wwwroot/backend
exec uvicorn api:app \
  --host 0.0.0.0 \
  --port "${PORT:-8000}" \
  --workers 2
