#!/bin/bash
set -e

echo "==> Installing frontend dependencies..."
pip install -r /home/site/wwwroot/frontend/requirements.txt

echo "==> Starting Inventory Planning Agent frontend..."
cd /home/site/wwwroot/frontend
exec python app.py
