import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer, CrossEncoder
from sklearn.metrics.pairwise import cosine_similarity
from typing import List, Tuple, Optional
from dotenv import load_dotenv 
import gradio as gr

load_dotenv()


class DocumentSimilaritySearch:
    def __init__(self, model_name="all-MiniLM-L6-v2", reranker_model="cross-encoder/ms-marco-MiniLM-L6-v2"):
        self.model = SentenceTransformer(model_name)
        self.reranker = CrossEncoder(reranker_model)
        self.documents = []
        self.embeddings = None
        
    def add_documents(self, documents):
        self.documents.extend(documents)
        self._compute_embeddings()
        
    def set_documents(self, documents):
        self.documents = documents
        self._compute_embeddings()
        
    def _compute_embeddings(self):
        if self.documents:
            self.embeddings = self.model.encode(self.documents)
        else:
            self.embeddings = None
            
    def get_top_k(self, query, k=None, documents=None):
        if documents and (documents != self.documents):
            self.set_documents(documents)
        if not self.documents or self.embeddings is None:
            return []
            
        query_embedding = self.model.encode([query])
        similarities = cosine_similarity(query_embedding, self.embeddings)[0]
        doc_similarity_pairs = list(zip(self.documents, similarities))
        doc_similarity_pairs.sort(key=lambda x: x[1], reverse=True)
        if k is not None:
            return doc_similarity_pairs[:k]
        
        return doc_similarity_pairs
    
    def get_similarities(self, query):
        if not self.documents or self.embeddings is None:
            return np.array([])
            
        query_embedding = self.model.encode([query])
        return cosine_similarity(query_embedding, self.embeddings)[0]
    
    def rerank(self, query, documents, top_k=None):
        if not documents:
            return []
        
        if isinstance(documents[0], tuple):
            doc_texts = [doc[0] for doc in documents]
        else:
            doc_texts = documents
        
        query_doc_pairs = [(query, doc) for doc in doc_texts]
        
        scores = self.reranker.predict(query_doc_pairs)
        
        doc_score_pairs = list(zip(doc_texts, scores))
        doc_score_pairs.sort(key=lambda x: x[1], reverse=True)
        
        if top_k is not None:
            return doc_score_pairs[:top_k]
        
        return doc_score_pairs
        

class DocumentSearchApp:
    def __init__(self):
        self.search_system = DocumentSimilaritySearch()
        self.documents = []
        self.top_k_results = None
        self.reranked_results = None
        
    def parse_documents(self, documents_text):
        """Parse documents from text input (one per line)"""
        return [doc.strip() for doc in documents_text.strip().split('\n') if doc.strip()]
    
    def retrieve_top_k(self, documents_text, query, k_value):
        """Retrieve top-k results"""
        if not documents_text.strip() or not query.strip():
            return None
        
        self.documents = self.parse_documents(documents_text)
        if len(self.documents) == 0:
            return None
        
        try:
            k = int(k_value) if k_value else len(self.documents)
            self.top_k_results = self.search_system.get_top_k(query, documents=self.documents, k=k)
            
            if not self.top_k_results:
                return None
            
            # Create DataFrame for display
            df = pd.DataFrame(self.top_k_results, columns=['Document', 'Score'])
            return df
        
        except Exception as e:
            return None
    
    def rerank_results(self, query):
        """Rerank the top-k results"""
        if self.top_k_results is None:
            return None
        
        if not query.strip():
            return None
        
        try:
            self.reranked_results = self.search_system.rerank(query, self.top_k_results)
            
            # Create DataFrame for display
            df = pd.DataFrame(self.reranked_results, columns=['Document', 'Score'])
            return df
        
        except Exception as e:
            return None
    
    def create_interface(self):
        """Create the Gradio interface"""
        with gr.Blocks(title="Document Similarity Search") as interface:
            gr.Markdown("# Document Similarity Search and Reranking")
            
            with gr.Row():
                with gr.Column(scale=2):
                    documents_input = gr.Textbox(
                        label="Documents (one per line)",
                        placeholder="Enter documents, one per line...",
                        lines=8,
                        value="COVID-19 has many symptoms.\nCOVID-19 symptoms are bad.\nCOVID-19 symptoms are not nice\nCOVID-19 symptoms are really bad. \nCOVID-19 is a disease caused by a virus. The most common symptoms are fever, chills, and sore throat, but there are a range of others.\nCOVID-19 symptoms can include: a high temperature or shivering (chills); a new, continuous cough; a loss or change to your sense of smell or taste; and many more\nDementia has the following symptom: Experiencing memory loss, poor judgment, and confusion.\nCOVID-19 has the following symptom: Experiencing memory loss, poor judgment, and confusion."
                    )
                
                with gr.Column(scale=1):
                    query_input = gr.Textbox(
                        label="Query",
                        placeholder="Enter search query...",
                        value="COVID-19 Symptoms"
                    )
                    
                    k_input = gr.Number(
                        label="K (number of results)",
                        value=8,
                        precision=0
                    )
            
            retrieve_btn = gr.Button("Retrieve Top K", variant="primary")
            
            top_k_results_display = gr.Dataframe(
                label="Top-K Results",
                headers=["Document", "Score"],
                interactive=False
            )
            
            rerank_btn = gr.Button("Rerank", variant="primary")
            
            reranked_results_display = gr.Dataframe(
                label="Reranked Results",
                headers=["Document", "Score"],
                interactive=False
            )
            
            retrieve_btn.click(
                fn=self.retrieve_top_k,
                inputs=[documents_input, query_input, k_input],
                outputs=[top_k_results_display]
            )
            
            rerank_btn.click(
                fn=self.rerank_results,
                inputs=[query_input],
                outputs=[reranked_results_display]
            )
        
        return interface


if __name__ == "__main__":
    app = DocumentSearchApp()
    interface = app.create_interface()
    interface.launch()
    exit()

    search_system = DocumentSimilaritySearch()
    documents = [
        "COVID-19 has many symptoms.",
        "COVID-19 symptoms are bad.",
        "COVID-19 symptoms are not nice",
        "COVID-19 symptoms are quite bad.",
        "COVID-19 is a disease caused by a virus. The most common symptoms are fever, chills, and sore throat, but there are a range of others.",
        "COVID-19 symptoms can include: a high temperature or shivering (chills); a new, continuous cough; a loss or change to your sense of smell or taste; and many more",
        "Dementia has the following symptom: Experiencing memory loss, poor judgment, and confusion.",
        "COVID-19 has the following symptom: Experiencing memory loss, poor judgment, and confusion."
    ]
    query = "COVID-19 Symptoms"
    top_k_results = search_system.get_top_k(query, documents=documents, k=8)

    print("Top-K Results:")
    for i, (doc, score) in enumerate(top_k_results):
        print(f"{i}: {doc} (Score: {score:.4f})")

    reranked_results = search_system.rerank(query, top_k_results)

    print("\nReranked Results:")
    for i, (doc, score) in enumerate(reranked_results):
        print(f"{i}: {doc} (Score: {score:.4f})")