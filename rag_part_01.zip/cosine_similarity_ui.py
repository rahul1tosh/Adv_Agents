#!/usr/bin/env python
import gradio as gr
import numpy as np
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")


def cosine_similarity(a, b):
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))


def retrieve_top_k(documents_text, query, k):
    docs = [d.strip() for d in documents_text.strip().splitlines() if d.strip()]
    if not docs or not query.strip():
        return []

    doc_embeddings = model.encode(docs)
    query_embedding = model.encode([query.strip()])[0]

    scores = [
        (doc, cosine_similarity(query_embedding, emb))
        for doc, emb in zip(docs, doc_embeddings)
    ]
    scores.sort(key=lambda x: x[1], reverse=True)

    return [[doc, f"{score:.4f}"] for doc, score in scores[: min(int(k), len(docs))]]


with gr.Blocks(title="Document Similarity Search", theme=gr.themes.Soft()) as demo:
    gr.Markdown("# Document Similarity Search and Reranking")
    gr.Markdown("Enter documents (one per line), type a query, and retrieve the top-K most similar documents ranked by cosine similarity.")

    with gr.Row(equal_height=True):
        documents_input = gr.Textbox(
            label="Documents (one per line)",
            lines=12,
            placeholder="The cat sat on the mat.\nA dog ran in the park.\nThe stock market crashed.\nBananas are a great source of potassium.",
            scale=2,
        )
        with gr.Column(scale=1):
            query_input = gr.Textbox(
                label="Query",
                placeholder="fruit and nutrition",
                lines=3,
            )
            k_input = gr.Slider(
                label="K — number of results",
                value=2,
                minimum=1,
                maximum=20,
                step=1,
            )
            retrieve_btn = gr.Button("Retrieve Top K", variant="primary", size="lg")

    results_table = gr.Dataframe(
        headers=["Document", "Similarity Score"],
        label="Top-K Results",
        interactive=False,
        wrap=True,
        row_count=(1, "dynamic"),
        column_widths=["75%", "25%"],
    )

    retrieve_btn.click(
        fn=retrieve_top_k,
        inputs=[documents_input, query_input, k_input],
        outputs=results_table,
    )

if __name__ == "__main__":
    demo.launch()
