import os
import re
from groq import Groq
from dotenv import load_dotenv
load_dotenv()

client = Groq(api_key=os.environ["GROQ_API_KEY"])

def evaluate_response(question, expected_answer, actual_response):
    """Use LLM to evaluate response with binary scores (0 or 1)."""
    eval_prompt = f"""Evaluate this inventory reorder advisor response with STRICT binary scoring (0=Fail, 1=Pass).

    Question: {question}
    Expected Key Points: {expected_answer}
    Actual Response: {actual_response}

    Be STRICT. Only give 1 if the criterion is fully met:
    - Accuracy: Is the reorder recommendation correct with NO errors or misleading statements? (0 or 1)
    - Clarity: Would a warehouse manager act on this WITHOUT further questions? (0 or 1)
    - Completeness: Does it address the SPECIFIC edge case or nuance in the question? (0 or 1)

    Respond ONLY in this exact format:
    Accuracy: X
    Clarity: X
    Completeness: X"""

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role": "user", "content": eval_prompt}],
        temperature=0,
    )
    text = response.choices[0].message.content
    scores = {}
    for metric in ["Accuracy", "Clarity", "Completeness"]:
        match = re.search(rf"{metric}\s*:\s*([01])", text, re.IGNORECASE)
        scores[metric] = int(match.group(1)) if match else 0
    return scores

def inventory_advisor(system_prompt, question):
    """Simple agent that answers inventory reorder questions based on the given prompt."""
    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": question},
        ],
        temperature=0.3,
    )
    return response.choices[0].message.content

dataset = [
    {
        "q": "Our safety stock formula says reorder at 200 units. We have 210 units on hand and a PO arriving tomorrow. Should we reorder now?",
        "a": "No. On-hand (210) is above reorder point (200) AND incoming stock will arrive tomorrow. Reordering now creates overstock. Must account for in-transit inventory in the reorder calculation.",
    },
    {
        "q": "Demand jumped 40% last week. Should I immediately raise the reorder point by 40%?",
        "a": "No. A single week's spike may be seasonal or anomalous. Must consider average demand over a rolling window (e.g., 4–8 weeks). Raising the reorder point by 40% based on one week risks permanent overstock.",
    },
    {
        "q": "We use EOQ to calculate order quantity. Our carrying cost just doubled. Should my order quantity go up or down?",
        "a": "Down. EOQ = sqrt(2DS/H). As H (holding cost) doubles, EOQ decreases. Ordering in smaller, more frequent batches is now cheaper than holding large lots.",
    },
    {
        "q": "Lead time from our supplier is 7 days. My reorder point is 70 units (10 units/day × 7 days). Is that correct?",
        "a": "Only in the ideal case with zero demand variability. In practice the reorder point must include safety stock: ROP = (avg demand × lead time) + safety stock. The formula is incomplete without safety stock for variable demand.",
    },
    {
        "q": "We have a perishable item with a 10-day shelf life. Our reorder cycle is every 8 days. Is there a problem?",
        "a": "Potentially yes. If the item arrives on day 1 and sits until the next order cycle, remaining shelf life when consumed could be very short. Must align reorder cycle with shelf life and consider FEFO (First Expired First Out) rotation.",
    },
    {
        "q": "Our ABC analysis puts item X in class C (low value). Can I just set a fixed reorder point and ignore it?",
        "a": "Not always. Class C items can still be operationally critical (e.g., a cheap bolt that stops an assembly line). Must distinguish between value-based ABC and criticality. Critical C items need tighter review despite low cost.",
    },
    {
        "q": "Supplier A has a unit price of $10 with 30-day lead time. Supplier B has $11 with 5-day lead time. Supplier A is always better, right?",
        "a": "No. Longer lead time requires higher safety stock, which increases holding costs. Total cost = purchase price + ordering cost + holding cost. Supplier B's shorter lead time may result in lower total inventory cost despite higher unit price.",
    },
    {
        "q": "We ran out of stock last month. I want to set safety stock high enough that we never stock out again. Is that achievable?",
        "a": "Not economically. Safety stock reduces stockout probability but cannot eliminate it without infinite inventory. Must choose a service level (e.g., 95% or 99%) and calculate the safety stock that achieves it, accepting a residual stockout risk.",
    },
    {
        "q": "Demand is perfectly constant at 50 units/day and lead time is always exactly 3 days. Do I need safety stock?",
        "a": "No. With zero variability in both demand and lead time, the reorder point is exactly 150 units (50 × 3) and safety stock = 0. Safety stock compensates for variability; if there is none, it adds cost without benefit.",
    },
]



prompts = {
    "Version 1": "You are an inventory management advisor. Answer the question.",
    "Version 2": """You are an inventory management advisor for warehouse operations teams.

    When answering questions:
    1. State the core inventory principle or formula first (e.g., EOQ, ROP, safety stock)
    2. Explain BOTH the textbook/ideal case AND the real-world complication if they differ
    3. Explicitly correct any common misconception embedded in the question
    4. Use concrete numbers from the question to illustrate your answer

    Always address the specific edge case or nuance — managers ask these questions because they have a hidden assumption that may be wrong.""",
}

q1 = dataset[0]["q"]
print(f"\nQUESTION 1:\n{q1}\n")
print("=" * 50)
for prompt_name in ["Version 1", "Version 2"]:
    response = inventory_advisor(prompts[prompt_name], q1)
    print(f"\n{prompt_name} ANSWER:")
    print("-" * 30)
    print(response)


results = {name: {"Accuracy": [], "Clarity": [], "Completeness": []} for name in prompts}

for prompt_name, prompt in prompts.items():
    print(f"\nEvaluating: {prompt_name}")
    for i, item in enumerate(dataset):
        response = inventory_advisor(prompt, item["q"])
        scores = evaluate_response(item["q"], item["a"], response)
        for metric in ["Accuracy", "Clarity", "Completeness"]:
            results[prompt_name][metric].append(scores.get(metric, 0))
        print(f"  Q{i+1}: {scores}")

print("\n" + "=" * 50)
print("PASS RATES BY PROMPT VERSION")
print("=" * 50)

for prompt_name in prompts:
    print(f"\n{prompt_name.upper()}:")
    total_pass = 0
    total_tests = 0
    for metric in ["Accuracy", "Clarity", "Completeness"]:
        passed = sum(results[prompt_name][metric])
        total = len(results[prompt_name][metric])
        total_pass += passed
        total_tests += total
        pct = (100 * passed / total) if total > 0 else 0
        print(f"  {metric}: {passed}/{total} ({pct:.0f}%)")
    overall_pct = (100 * total_pass / total_tests) if total_tests > 0 else 0
    print(f"  Overall: {total_pass}/{total_tests} ({overall_pct:.0f}%)")
