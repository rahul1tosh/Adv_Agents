"""
RAG Evaluation — Inventory Reordering Case Study

1. RAG evaluation metrics (3 binary: Context Relevance, Answer Groundedness, Answer Correctness)
2. Document corpus  (inventory policy knowledge base)
3. Simple RAG agent (sentence-transformer embeddings + cosine similarity)
4. Synthetic evaluation dataset (10 Q&A)
5. RAG configurations (Config A: k=1 minimal, B: k=2 structured, C: k=3 grounded)
6. Run evaluation
7. Results comparison
"""

import os
import re
import numpy as np
from groq import Groq
from sentence_transformers import SentenceTransformer

client = Groq(api_key=os.environ["GROQ_API_KEY"])

NUM_QUESTIONS = 5  # set to 10 for full run


def evaluate_rag_response(question, retrieved_context, generated_answer, reference_answer):
    """Evaluate RAG response on 3 metrics using LLM-as-judge (binary 0/1)."""
    eval_prompt = f"""You are evaluating a RAG system for inventory management. Be STRICT with scoring.

    Question: {question}
    Retrieved Context: {retrieved_context}
    Generated Answer: {generated_answer}
    Reference Answer: {reference_answer}

    Evaluate these 3 metrics:

    1. Context Relevance (0 or 1):
    Does the retrieved context contain ALL information needed to fully answer the question?
    Score 0 if the context is missing key facts mentioned in the reference answer.

    2. Answer Groundedness (0 or 1):
    Is EVERY claim in the generated answer explicitly supported by the retrieved context?
    Score 0 if the answer includes ANY information not found in the context.
    Score 0 if the answer adds details or numbers beyond what the context provides.

    3. Answer Correctness (0 or 1):
    Does the generated answer match the reference answer's key facts?
    Score 0 if any key information is wrong or missing.

    Respond ONLY in this format:
    Context Relevance: X
    Answer Groundedness: X
    Answer Correctness: X"""

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": eval_prompt}],
        temperature=0,
    )
    text = response.choices[0].message.content
    scores = {}
    for metric in ["Context Relevance", "Answer Groundedness", "Answer Correctness"]:
        match = re.search(rf"{metric}\s*:\s*([01])", text, re.IGNORECASE)
        scores[metric] = int(match.group(1)) if match else 0
    return scores



documents = [
    # Doc 0: Reorder point basics
    "A reorder point (ROP) is the inventory level that triggers a new purchase order. "
    "It is calculated as: ROP = average daily demand × lead time in days.",

    # Doc 1: Safety stock (needs Doc 0 for full picture)
    "Safety stock is extra inventory held to guard against demand spikes and lead-time variability. "
    "The full reorder point formula is: ROP = (average demand × lead time) + safety stock. "
    "Without safety stock the formula only works when demand and lead time are perfectly constant.",

    # Doc 2: EOQ definition
    "Economic Order Quantity (EOQ) is the order size that minimises total inventory cost. "
    "Formula: EOQ = sqrt(2 × D × S / H), where D = annual demand, S = ordering cost, H = holding cost per unit per year.",

    # Doc 3: EOQ sensitivity (needs Doc 2)
    "In the EOQ formula, holding cost H is in the denominator under the square root. "
    "When holding cost doubles, EOQ decreases — it becomes cheaper to order smaller quantities more frequently. "
    "Conversely, when ordering cost S rises, EOQ increases.",

    # Doc 4: ABC classification basics
    "ABC analysis classifies inventory by value: A items are high-value (top 70-80% of spend), "
    "B items are medium-value, and C items are low-value (bottom 5% of spend). "
    "Cycle count frequency and review effort are typically proportional to class.",

    # Doc 5: ABC criticality caveat (needs Doc 4)
    "ABC classification is based on monetary value, not operational importance. "
    "A low-value (Class C) item can still be operationally critical — for example, a cheap O-ring "
    "that stops an entire production line. Critical C items require tighter controls despite low cost.",

    # Doc 6: Lead time and supplier trade-offs
    "Supplier lead time directly affects required safety stock and reorder point. "
    "A supplier with a longer lead time forces higher safety stock, increasing holding costs. "
    "Total procurement cost = unit price + ordering cost + holding cost; a higher-priced supplier "
    "with shorter lead time may have lower total cost than a cheaper supplier with long lead time.",

    # Doc 7: Service level and stockout risk (needs Doc 1)
    "A 100% service level (zero stockout) would require infinite safety stock, which is not economically viable. "
    "Companies choose a target service level (e.g., 95% or 99%) and calculate the safety stock needed to achieve it "
    "using the formula: safety stock = Z × σ_demand × sqrt(lead time), where Z is the service-level z-score.",

    # Doc 8: Perishable inventory
    "Perishable items have a finite shelf life. The reorder cycle must be short enough that items are consumed "
    "before expiry. FEFO (First Expired First Out) rotation ensures oldest stock is picked first. "
    "If the reorder cycle approaches the shelf life, there is a risk of expiry before consumption.",

    # Doc 9: In-transit inventory
    "In-transit (pipeline) inventory refers to stock already ordered but not yet received. "
    "When calculating whether to reorder, on-hand inventory plus in-transit inventory should both be compared "
    "against the reorder point. Reordering when in-transit stock will bring inventory above ROP causes overstock.",

    # Doc 10: Demand variability and averaging
    "A single week of unusually high demand should not immediately trigger a permanent change to the reorder point. "
    "Demand should be averaged over a rolling window (typically 4–8 weeks) to smooth out anomalies. "
    "Reacting to a single spike risks permanent overstock if the spike was seasonal or one-off.",

    # Doc 11: Zero-variability special case (needs Doc 1 and Doc 7)
    "When both demand and lead time are perfectly constant with zero variability, safety stock is zero. "
    "The reorder point equals exactly: average demand × lead time. "
    "Safety stock exists to absorb variability; if there is none, safety stock adds cost without benefit.",
]

print(f"Corpus: {len(documents)} documents")


embedder = SentenceTransformer("all-MiniLM-L6-v2")
print("Embedding model loaded!")


def get_embedding(text):
    return embedder.encode(text, convert_to_numpy=True)


def similarity(e1, e2):
    return np.dot(e1, e2) / (np.linalg.norm(e1) * np.linalg.norm(e2))


def retrieve(query, docs, k=2):
    q_emb = get_embedding(query)
    scores = [(doc, similarity(q_emb, get_embedding(doc))) for doc in docs]
    scores.sort(key=lambda x: x[1], reverse=True)
    return [doc for doc, _ in scores[:k]]


PROMPT_MINIMAL = """Context: {context}

Question: {question}
Answer:"""

PROMPT_STRUCTURED = """Use the context below to answer the inventory question.

Context:
{context}

Question: {question}
Answer based on the context:"""

PROMPT_GROUNDED = """You are an inventory management advisor. Answer using ONLY the provided context.
Combine information from all context passages to give a complete answer.
If the context is incomplete, say what's missing.

Context:
{context}

Question: {question}
Answer (use all relevant context):"""


def rag_agent(question, docs, k=2, prompt_template=PROMPT_MINIMAL):
    """RAG agent: retrieve context, then generate answer."""
    retrieved = retrieve(question, docs, k=k)
    context = "\n---\n".join(retrieved)
    prompt = prompt_template.format(context=context, question=question)
    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
    )
    return {"context": context, "answer": response.choices[0].message.content}


eval_dataset = [
    {
        "question": "What is the reorder point formula and when should safety stock be included?",
        "reference": "ROP = average demand × lead time. Safety stock must be added when demand or lead time vary: ROP = (avg demand × lead time) + safety stock.",
        "docs_needed": 2,  # Doc 0 + Doc 1
    },
    {
        "question": "If our holding cost doubles, should we increase or decrease our order quantity?",
        "reference": "Decrease. In EOQ = sqrt(2DS/H), H is in the denominator. Doubling H reduces EOQ — smaller, more frequent orders become cheaper.",
        "docs_needed": 2,  # Doc 2 + Doc 3
    },
    {
        "question": "A Class C item has very low cost. Can we safely ignore it in cycle counts?",
        "reference": "Not always. ABC is value-based, not criticality-based. A cheap Class C item can be operationally critical and stop a production line. Critical C items need tighter controls.",
        "docs_needed": 2,  # Doc 4 + Doc 5
    },
    {
        "question": "Supplier A is cheaper per unit but has a 30-day lead time. Supplier B costs more but delivers in 5 days. How should we evaluate them?",
        "reference": "Compare total cost = unit price + ordering cost + holding cost. Longer lead time forces higher safety stock and higher holding costs. Supplier B may have lower total cost despite higher unit price.",
        "docs_needed": 2,  # Doc 6 + Doc 1
    },
    {
        "question": "Can we set safety stock high enough to guarantee we never stock out?",
        "reference": "No. 100% service level requires infinite safety stock. Choose a target service level (e.g., 95% or 99%) and calculate safety stock using: safety stock = Z × σ_demand × sqrt(lead time).",
        "docs_needed": 2,  # Doc 7 + Doc 1
    },
    {
        "question": "We have a perishable product with a 10-day shelf life and reorder every 8 days. Is there a risk?",
        "reference": "Yes. If stock arrives and sits near the end of the cycle, remaining shelf life at time of use could be very short. Use FEFO rotation and ensure the reorder cycle is well within shelf life.",
        "docs_needed": 1,  # Doc 8
    },
    {
        "question": "We have 220 units on hand and a PO of 100 units arriving tomorrow. ROP is 200. Should we reorder?",
        "reference": "No. On-hand (220) already exceeds ROP (200), and in-transit stock (100) will push inventory even higher. Reordering now causes overstock. Always include in-transit inventory in the reorder check.",
        "docs_needed": 2,  # Doc 9 + Doc 0
    },
    {
        "question": "Demand spiked 50% last week. Should I immediately raise the reorder point by 50%?",
        "reference": "No. A single week's spike may be seasonal or anomalous. Average demand over a rolling 4–8 week window before adjusting the reorder point. Reacting to one spike risks permanent overstock.",
        "docs_needed": 2,  # Doc 10 + Doc 0
    },
    {
        "question": "Our demand is exactly 40 units/day and lead time is always exactly 5 days. Do we need safety stock?",
        "reference": "No. With zero variability in both demand and lead time, ROP = 40 × 5 = 200 units and safety stock = 0. Safety stock compensates for variability; with none, it only adds holding cost.",
        "docs_needed": 2,  # Doc 11 + Doc 1
    },
    {
        "question": "What is EOQ and what happens to it when ordering cost increases?",
        "reference": "EOQ = sqrt(2DS/H). When ordering cost S increases, EOQ increases — it becomes cheaper to order larger quantities less frequently to spread the fixed ordering cost.",
        "docs_needed": 2,  # Doc 2 + Doc 3
    },
]

print(f"Evaluation dataset: {len(eval_dataset)} questions")
print(f"Average docs needed per question: {sum(d['docs_needed'] for d in eval_dataset) / len(eval_dataset):.1f}")



rag_configs = {
    "Config A: k=1, minimal":    {"k": 1, "prompt": PROMPT_MINIMAL},
    "Config B: k=2, structured": {"k": 2, "prompt": PROMPT_STRUCTURED},
    "Config C: k=3, grounded":   {"k": 3, "prompt": PROMPT_GROUNDED},
}

print("RAG Configurations:")
for name, cfg in rag_configs.items():
    print(f"  {name} (retrieves {cfg['k']} doc(s))")



metrics = ["Context Relevance", "Answer Groundedness", "Answer Correctness"]
results = {name: {m: [] for m in metrics} for name in rag_configs}
test_data = eval_dataset[:NUM_QUESTIONS]

for config_name, config in rag_configs.items():
    print(f"\nEvaluating: {config_name}")
    for i, item in enumerate(test_data):
        rag_output = rag_agent(item["question"], documents, k=config["k"], prompt_template=config["prompt"])
        scores = evaluate_rag_response(item["question"], rag_output["context"], rag_output["answer"], item["reference"])
        for metric, score in scores.items():
            results[config_name][metric].append(score)
        print(f"  Q{i+1}: {scores}")

print(f"\n(Evaluated {NUM_QUESTIONS} questions per config)")

print("\n" + "=" * 70)
print("RAG EVALUATION RESULTS")
print("=" * 70)
print(f"{'Configuration':<35} {'Relevance':>10} {'Grounded':>10} {'Correct':>10} {'Overall':>10}")
print("-" * 70)

best_config, best_score = None, 0

for config_name in rag_configs:
    n = len(results[config_name]["Context Relevance"])
    relevance = sum(results[config_name]["Context Relevance"]) / n
    grounded  = sum(results[config_name]["Answer Groundedness"]) / n
    correct   = sum(results[config_name]["Answer Correctness"]) / n
    overall   = (relevance + grounded + correct) / 3
    print(f"{config_name:<35} {relevance:>10.0%} {grounded:>10.0%} {correct:>10.0%} {overall:>10.0%}")
    if overall > best_score:
        best_score, best_config = overall, config_name

print("-" * 70)
print(f"Best: {best_config} ({best_score:.0%})")
