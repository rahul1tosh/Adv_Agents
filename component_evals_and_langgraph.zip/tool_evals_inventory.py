
# Optional read on tool evals
import os
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import pandas as pd
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain.prompts import ChatPromptTemplate
from langchain.tools import tool
from langchain_groq import ChatGroq

from dotenv import load_dotenv
load_dotenv()


@tool
def reorder_point_calculator(avg_daily_demand: float, lead_time_days: float, safety_stock: float = 0) -> str:
    """Calculate reorder point: ROP = (avg_daily_demand * lead_time_days) + safety_stock."""
    rop = avg_daily_demand * lead_time_days + safety_stock
    return f"Reorder Point = {rop:.1f} units (demand {avg_daily_demand}/day × {lead_time_days} days lead time + {safety_stock} safety stock)"


@tool
def eoq_calculator(annual_demand: float, ordering_cost: float, holding_cost_per_unit: float) -> str:
    """Calculate Economic Order Quantity: EOQ = sqrt(2 * D * S / H)."""
    if holding_cost_per_unit <= 0:
        return "Error: holding cost must be > 0"
    eoq = math.sqrt(2 * annual_demand * ordering_cost / holding_cost_per_unit)
    return f"EOQ = {eoq:.1f} units (D={annual_demand}, S=${ordering_cost}, H=${holding_cost_per_unit})"


@tool
def safety_stock_calculator(z_score: float, demand_std_dev: float, lead_time_days: float) -> str:
    """Calculate safety stock: SS = Z * σ_demand * sqrt(lead_time)."""
    ss = z_score * demand_std_dev * math.sqrt(lead_time_days)
    return f"Safety Stock = {ss:.1f} units (Z={z_score}, σ={demand_std_dev}, LT={lead_time_days} days)"


@tool
def days_of_supply_calculator(on_hand_units: float, avg_daily_demand: float) -> str:
    """Calculate days of supply remaining: DoS = on_hand / avg_daily_demand."""
    if avg_daily_demand <= 0:
        return "Error: daily demand must be > 0"
    dos = on_hand_units / avg_daily_demand
    return f"Days of Supply = {dos:.1f} days ({on_hand_units} units ÷ {avg_daily_demand} units/day)"


@tool
def abc_classifier(annual_spend_pct: float) -> str:
    """Classify an inventory item as A, B, or C based on its share of total annual spend (0-100)."""
    if annual_spend_pct >= 70:
        cls = "A"
        desc = "high-value — tight control, frequent review"
    elif annual_spend_pct >= 20:
        cls = "B"
        desc = "medium-value — moderate review"
    else:
        cls = "C"
        desc = "low-value — simplified control (but check criticality)"
    return f"Class {cls}: {annual_spend_pct:.1f}% of annual spend — {desc}"


@tool
def inventory_date_info() -> str:
    """Return today's date for reorder scheduling and expiry calculations."""
    from datetime import date
    today = date.today()
    return f"Today is {today.strftime('%A, %B %d, %Y')} (week {today.isocalendar()[1]} of {today.year})"


tools = [
    reorder_point_calculator,
    eoq_calculator,
    safety_stock_calculator,
    days_of_supply_calculator,
    abc_classifier,
    inventory_date_info,
]

print(f"Defined {len(tools)} tools: {[t.name for t in tools]}")

llm = ChatGroq(model="llama-3.3-70b-versatile", temperature=0)

prompt = ChatPromptTemplate.from_messages([
    ("system", """You are an inventory management assistant with access to calculation tools.
Use the appropriate tool(s) to answer inventory questions precisely.
Always use tools when they are relevant to the question.
Be precise in selecting the right tool for each task."""),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])

agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, return_intermediate_steps=True)

print("Agent created successfully!")


# ---------------------------------------------------------------------------
# 4. Define Test Scenarios
# ---------------------------------------------------------------------------

test_scenarios = [
    # Single-tool
    {"question": "Calculate the reorder point for an item with 50 units/day demand, 7-day lead time, and 100 units safety stock.",
     "expected_tools": ["reorder_point_calculator"], "category": "single_tool", "requires_external_data": True, "optimal_tool_count": 1},
    {"question": "What is the EOQ for annual demand of 10000 units, ordering cost $50, holding cost $2 per unit?",
     "expected_tools": ["eoq_calculator"], "category": "single_tool", "requires_external_data": True, "optimal_tool_count": 1},
    {"question": "Calculate safety stock using Z=1.65, demand std dev of 20 units, and 5-day lead time.",
     "expected_tools": ["safety_stock_calculator"], "category": "single_tool", "requires_external_data": True, "optimal_tool_count": 1},
    {"question": "We have 800 units on hand and sell 40 units per day. How many days of supply do we have?",
     "expected_tools": ["days_of_supply_calculator"], "category": "single_tool", "requires_external_data": True, "optimal_tool_count": 1},
    {"question": "An item represents 5% of our annual spend. What ABC class is it?",
     "expected_tools": ["abc_classifier"], "category": "single_tool", "requires_external_data": True, "optimal_tool_count": 1},
    {"question": "What is today's date? I need to schedule a reorder.",
     "expected_tools": ["inventory_date_info"], "category": "single_tool", "requires_external_data": True, "optimal_tool_count": 1},

    # Multi-tool
    {"question": "Calculate the EOQ for D=5000, S=$30, H=$4, and also tell me today's date so I can schedule the first order.",
     "expected_tools": ["eoq_calculator", "inventory_date_info"], "category": "multi_tool", "requires_external_data": True, "optimal_tool_count": 2},
    {"question": "Our item has 30 units/day demand, 10-day lead time, no safety stock. Calculate the ROP and how many days 450 units on hand will last.",
     "expected_tools": ["reorder_point_calculator", "days_of_supply_calculator"], "category": "multi_tool", "requires_external_data": True, "optimal_tool_count": 2},

    # Ambiguous
    {"question": "What is 2 * 5000 * 30 / 4 and then take the square root?",
     "expected_tools": ["eoq_calculator"], "category": "ambiguous",
     "acceptable_alternatives": [], "requires_external_data": True, "optimal_tool_count": 1},
    {"question": "Tell me about right now so I can timestamp my inventory report.",
     "expected_tools": ["inventory_date_info"], "category": "ambiguous", "requires_external_data": True, "optimal_tool_count": 1},

    # No tool needed
    {"question": "What does FEFO stand for in warehouse management?",
     "expected_tools": [], "category": "no_tool", "requires_external_data": False, "optimal_tool_count": 0},
    {"question": "Explain the difference between cycle stock and safety stock.",
     "expected_tools": [], "category": "no_tool", "requires_external_data": False, "optimal_tool_count": 0},
]

print(f"Defined {len(test_scenarios)} test scenarios:")
for i, s in enumerate(test_scenarios, 1):
    print(f"  {i}. [{s['category']}] {s['question'][:60]}...")


# ---------------------------------------------------------------------------
# 5. Enhanced Data Structures
# ---------------------------------------------------------------------------

@dataclass
class ToolCallLog:
    tool_name: str
    parameters: Dict[str, Any]
    output: str
    success: bool
    is_correct: bool
    execution_time_ms: float = 0.0
    retry_count: int = 0
    TOOL_COST_PER_CALL: float = field(default=0.001, init=False, repr=False)

    @property
    def cost(self) -> float:
        return 0.001 * (1 + self.retry_count)


@dataclass
class TaskEvaluation:
    question: str
    category: str
    expected_tools: List[str]
    actual_tools: List[str]
    tool_call_logs: List[ToolCallLog]
    output: Optional[str]
    error: Optional[str]
    requires_external_data: bool
    optimal_tool_count: int
    acceptable_alternatives: List[List[str]] = field(default_factory=list)
    input_tokens: int = 0
    output_tokens: int = 0
    COST_PER_1K_INPUT_TOKENS: float = field(default=0.0005, init=False, repr=False)
    COST_PER_1K_OUTPUT_TOKENS: float = field(default=0.001, init=False, repr=False)

    @property
    def task_success(self) -> bool:
        return self.error is None and self.output is not None

    @property
    def llm_cost(self) -> float:
        return (self.input_tokens / 1000) * 0.0005 + (self.output_tokens / 1000) * 0.001

    @property
    def tool_cost(self) -> float:
        return sum(log.cost for log in self.tool_call_logs)

    @property
    def total_cost(self) -> float:
        return self.llm_cost + self.tool_cost


print("Enhanced data structures defined!")


# ---------------------------------------------------------------------------
# 6. Evaluation Helper Functions
# ---------------------------------------------------------------------------

def is_correct_tool(tool_name: str, expected_tools: List[str], alternatives: List[List[str]]) -> bool:
    if tool_name in expected_tools:
        return True
    for alt_set in alternatives:
        if tool_name in alt_set:
            return True
    return False


def run_evaluation(scenario: dict) -> TaskEvaluation:
    expected = scenario["expected_tools"]
    alternatives = scenario.get("acceptable_alternatives", [])
    actual_tools, tool_logs = [], []
    output, error = None, None
    input_tokens, output_tokens = 0, 0

    try:
        t0 = time.time()
        result = agent_executor.invoke({"input": scenario["question"]})
        elapsed_ms = (time.time() - t0) * 1000
        output = result.get("output")

        for step in result.get("intermediate_steps", []):
            action, obs = step
            tool_name = action.tool
            actual_tools.append(tool_name)
            params = action.tool_input if isinstance(action.tool_input, dict) else {"input": action.tool_input}
            success = "error" not in str(obs).lower()
            tool_logs.append(ToolCallLog(
                tool_name=tool_name,
                parameters=params,
                output=str(obs),
                success=success,
                is_correct=is_correct_tool(tool_name, expected, alternatives),
                execution_time_ms=elapsed_ms,
            ))

        if hasattr(result, "llm_output") and result.llm_output:
            token_usage = result.llm_output.get("token_usage", {})
            input_tokens = token_usage.get("prompt_tokens", 0)
            output_tokens = token_usage.get("completion_tokens", 0)

    except Exception as e:
        error = str(e)

    return TaskEvaluation(
        question=scenario["question"],
        category=scenario["category"],
        expected_tools=expected,
        actual_tools=actual_tools,
        tool_call_logs=tool_logs,
        output=output,
        error=error,
        requires_external_data=scenario["requires_external_data"],
        optimal_tool_count=scenario["optimal_tool_count"],
        acceptable_alternatives=alternatives,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
    )


# ---------------------------------------------------------------------------
# 7. Run Evaluation
# ---------------------------------------------------------------------------

print("\nRunning evaluation...")
evaluation_results: List[TaskEvaluation] = []
for i, scenario in enumerate(test_scenarios, 1):
    print(f"\n--- Scenario {i}/{len(test_scenarios)}: [{scenario['category']}] ---")
    eval_result = run_evaluation(scenario)
    evaluation_results.append(eval_result)
    status = "OK" if eval_result.task_success else f"ERROR: {eval_result.error}"
    print(f"  Expected: {eval_result.expected_tools} | Actual: {eval_result.actual_tools} | {status}")


# ---------------------------------------------------------------------------
# 8. Tool Invocation Precision
# ---------------------------------------------------------------------------
# Precision = correct_tool_calls / total_tool_calls

def compute_precision(results: List[TaskEvaluation]) -> Dict:
    total_calls = sum(len(r.actual_tools) for r in results)
    correct_calls = sum(log.is_correct for r in results for log in r.tool_call_logs)
    overall = correct_calls / total_calls if total_calls else 1.0
    per_task = []
    for r in results:
        if r.actual_tools:
            p = sum(log.is_correct for log in r.tool_call_logs) / len(r.actual_tools)
        else:
            p = 1.0 if not r.expected_tools else 0.0
        per_task.append(p)
    return {"overall_precision": overall, "avg_task_precision": sum(per_task) / len(per_task), "per_task": per_task}


# ---------------------------------------------------------------------------
# 9. Tool Invocation Recall
# ---------------------------------------------------------------------------
# Recall = correct_tool_calls / expected_tool_calls

def compute_recall(results: List[TaskEvaluation]) -> Dict:
    total_expected = sum(len(r.expected_tools) for r in results)
    correct_calls = sum(log.is_correct for r in results for log in r.tool_call_logs)
    overall = correct_calls / total_expected if total_expected else 1.0
    per_task = []
    for r in results:
        if r.expected_tools:
            recalled = sum(1 for t in r.actual_tools if is_correct_tool(t, r.expected_tools, r.acceptable_alternatives))
            rec = min(recalled, len(r.expected_tools)) / len(r.expected_tools)
        else:
            rec = 1.0 if not r.actual_tools else 0.0
        per_task.append(rec)
    return {"overall_recall": overall, "avg_task_recall": sum(per_task) / len(per_task), "per_task": per_task}


# ---------------------------------------------------------------------------
# 10. Average Tool Calls per Task
# ---------------------------------------------------------------------------

def compute_avg_tool_calls(results: List[TaskEvaluation]) -> Dict:
    counts = {"too_few": 0, "optimal": 0, "too_many": 0}
    calls_per_task = []
    for r in results:
        n = len(r.actual_tools)
        calls_per_task.append(n)
        if n < r.optimal_tool_count:
            counts["too_few"] += 1
        elif n == r.optimal_tool_count:
            counts["optimal"] += 1
        else:
            counts["too_many"] += 1
    total = len(results)
    return {
        "avg_calls_per_task": sum(calls_per_task) / total,
        "total_calls": sum(calls_per_task),
        "efficiency_counts": counts,
        "efficiency_rate": {k: v / total for k, v in counts.items()},
        "calls_per_task": calls_per_task,
    }


# ---------------------------------------------------------------------------
# 11. Tool Success Rate
# ---------------------------------------------------------------------------

def compute_tool_success_rate(results: List[TaskEvaluation]) -> Dict:
    all_logs = [log for r in results for log in r.tool_call_logs]
    total = len(all_logs)
    successful = sum(log.success for log in all_logs)
    return {
        "overall_success_rate": successful / total if total else 1.0,
        "successful_calls": successful,
        "failed_calls": total - successful,
        "total_calls": total,
    }


# ---------------------------------------------------------------------------
# 12. Tool-Attributable Task Success
# ---------------------------------------------------------------------------

def compute_attribution(results: List[TaskEvaluation]) -> Dict:
    tool_required = [r for r in results if r.requires_external_data]
    attributed = [
        r for r in tool_required
        if r.task_success and r.actual_tools and r.output and
        any(kw in r.output.lower() for log in r.tool_call_logs for kw in log.output.lower().split()[:5])
    ]
    n = len(tool_required)
    return {"attribution_rate": len(attributed) / n if n else 0.0, "attributed": len(attributed), "tool_required": n}


# ---------------------------------------------------------------------------
# 13. Cost per Successful Task
# ---------------------------------------------------------------------------

def compute_cost(results: List[TaskEvaluation]) -> Dict:
    total_cost = sum(r.total_cost for r in results)
    successful = [r for r in results if r.task_success]
    cost_per_success = total_cost / len(successful) if successful else 0.0
    if cost_per_success < 0.001:
        classification = "Low"
    elif cost_per_success < 0.01:
        classification = "Moderate"
    else:
        classification = "High"
    return {
        "total_cost": total_cost,
        "cost_per_success": cost_per_success,
        "cost_classification": classification,
        "successful_tasks": len(successful),
    }


# ---------------------------------------------------------------------------
# 14. Consolidated Summary
# ---------------------------------------------------------------------------

precision_metrics   = compute_precision(evaluation_results)
recall_metrics      = compute_recall(evaluation_results)
avg_calls_metrics   = compute_avg_tool_calls(evaluation_results)
success_metrics     = compute_tool_success_rate(evaluation_results)
attribution_metrics = compute_attribution(evaluation_results)
cost_metrics        = compute_cost(evaluation_results)

summary_data = [
    {"Category": "Tool Invocation", "Metric": "Precision (Overall)",    "Value": f"{precision_metrics['overall_precision']:.3f}",   "Description": "Correct calls / Total calls"},
    {"Category": "Tool Invocation", "Metric": "Precision (Avg/Task)",   "Value": f"{precision_metrics['avg_task_precision']:.3f}",  "Description": "Average precision across tasks"},
    {"Category": "Tool Invocation", "Metric": "Recall (Overall)",       "Value": f"{recall_metrics['overall_recall']:.3f}",         "Description": "Recalled / Expected"},
    {"Category": "Tool Invocation", "Metric": "Recall (Avg/Task)",      "Value": f"{recall_metrics['avg_task_recall']:.3f}",        "Description": "Average recall across tasks"},
    {"Category": "Efficiency",      "Metric": "Avg Calls per Task",     "Value": f"{avg_calls_metrics['avg_calls_per_task']:.2f}",  "Description": "Mean tool invocations"},
    {"Category": "Efficiency",      "Metric": "Optimal Call Rate",      "Value": f"{avg_calls_metrics['efficiency_rate']['optimal']:.1%}", "Description": "Tasks with optimal tool count"},
    {"Category": "Efficiency",      "Metric": "Over-calling Rate",      "Value": f"{avg_calls_metrics['efficiency_rate']['too_many']:.1%}", "Description": "Tasks with excess tool calls"},
    {"Category": "Efficiency",      "Metric": "Under-calling Rate",     "Value": f"{avg_calls_metrics['efficiency_rate']['too_few']:.1%}",  "Description": "Tasks with insufficient calls"},
    {"Category": "Success",         "Metric": "Tool Success Rate",      "Value": f"{success_metrics['overall_success_rate']:.3f}",  "Description": "Successful / Total calls"},
    {"Category": "Success",         "Metric": "Failed Tool Calls",      "Value": str(success_metrics['failed_calls']),              "Description": "Number of failed executions"},
    {"Category": "Success",         "Metric": "Attribution Rate",       "Value": f"{attribution_metrics['attribution_rate']:.3f}",  "Description": "Tool-attributable successes"},
    {"Category": "Cost",            "Metric": "Total Cost",             "Value": f"${cost_metrics['total_cost']:.6f}",              "Description": "LLM + Tool costs"},
    {"Category": "Cost",            "Metric": "Cost per Success",       "Value": f"${cost_metrics['cost_per_success']:.6f}",        "Description": "Cost per successful task"},
    {"Category": "Cost",            "Metric": "Cost Classification",    "Value": cost_metrics['cost_classification'],               "Description": "Low/Moderate/High"},
]

summary_df = pd.DataFrame(summary_data)
print("\n" + "=" * 80)
print("CONSOLIDATED EVALUATION SUMMARY")
print("=" * 80)
print(summary_df.to_string(index=False))


# ---------------------------------------------------------------------------
# 15. Per-Task Detailed Results
# ---------------------------------------------------------------------------

rows = []
for i, r in enumerate(evaluation_results, 1):
    exp_set = set(r.expected_tools)
    act_set = set(r.actual_tools)
    precision = len(exp_set & act_set) / len(act_set) if act_set else (1.0 if not exp_set else 0.0)
    recall    = len(exp_set & act_set) / len(exp_set) if exp_set else (1.0 if not act_set else 0.0)
    rows.append({
        "#": i,
        "Question": r.question[:45] + "...",
        "Category": r.category,
        "Expected": ", ".join(r.expected_tools) or "None",
        "Actual":   ", ".join(r.actual_tools)   or "None",
        "Precision": f"{precision:.2f}",
        "Recall":    f"{recall:.2f}",
        "Success":   "Yes" if r.task_success else "No",
        "Cost":      f"${r.total_cost:.5f}",
    })

per_task_df = pd.DataFrame(rows)
print("\n" + "=" * 100)
print("PER-TASK DETAILED RESULTS")
print("=" * 100)
print(per_task_df.to_string(index=False))
