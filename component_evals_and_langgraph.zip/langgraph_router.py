import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.graph import StateGraph, END
from typing import TypedDict
from pydantic import BaseModel
from typing import Literal

load_dotenv()

llm = ChatGroq(model="llama-3.1-8b-instant", temperature=0)

def ask(system, user):
    return llm.invoke([SystemMessage(content=system), HumanMessage(content=user)]).content

class Route(BaseModel):
    category: Literal["reorder", "forecast", "supplier"]

router_llm = llm.with_structured_output(Route)

class State(TypedDict):
    query: str
    category: str
    response: str

def router(state):
    decision = router_llm.invoke([
        SystemMessage(content="Route the inventory query to one of: reorder, forecast, or supplier.\n- reorder: reorder point, EOQ, safety stock, when to order\n- forecast: demand prediction, adjusting forecasts\n- supplier: comparing suppliers, lead times, vendor costs"),
        HumanMessage(content=state["query"]),
    ])
    return {"category": decision.category}

def reorder_node(state):
    answer = ask(
        "You are an inventory reorder specialist. Answer concisely using inventory principles like ROP, EOQ, and safety stock.",
        state["query"],
    )
    return {"response": answer}

def forecast_node(state):
    answer = ask(
        "You are a demand forecasting specialist. Answer concisely using concepts like rolling averages, seasonality, and trend.",
        state["query"],
    )
    return {"response": answer}

def supplier_node(state):
    answer = ask(
        "You are a supplier management specialist. Answer concisely using concepts like lead time, total cost, and vendor reliability.",
        state["query"],
    )
    return {"response": answer}

def route_edge(state):
    return state["category"]

graph = StateGraph(State)
graph.add_node("router", router)
graph.add_node("reorder", reorder_node)
graph.add_node("forecast", forecast_node)
graph.add_node("supplier", supplier_node)

graph.set_entry_point("router")
graph.add_conditional_edges("router", route_edge, {"reorder": "reorder", "forecast": "forecast", "supplier": "supplier"})
graph.add_edge("reorder", END)
graph.add_edge("forecast", END)
graph.add_edge("supplier", END)

app = graph.compile()

queries = [
    "We have 300 units on hand and sell 30 a day with a 5-day lead time. Should we reorder?",
    "Demand spiked 60% last week. How should I adjust my forecast?",
    "Supplier A is cheaper but takes 30 days. Supplier B costs more but delivers in 5 days. Which is better?",
]

for q in queries:
    result = app.invoke({"query": q, "category": "", "response": ""})
    print(f"\nQuery    : {q}")
    print(f"Category : {result['category']}")
    print(f"Response : {result['response']}")
    print("-" * 60)
