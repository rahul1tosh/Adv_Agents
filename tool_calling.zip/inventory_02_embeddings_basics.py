
import numpy as np
from sentence_transformers import SentenceTransformer

PASSAGES = [
    "Safety Stock = Z-score * sqrt(lead_time) * avg_daily_demand",
    "Reorder Point = (avg_daily_demand * lead_time) + safety_stock",
    "Electronics: lead times 14-30 days, high obsolescence risk.",
    "Pharma: strict FIFO, 99%+ service level, expiry management.",
    "FMCG: short lead times 3-7 days, high steady demand.",
    "ABC Analysis: A-items need tight control, C-items tolerate bulk orders.",
]

model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

print("Embedding passages...")
passage_vectors = model.encode(PASSAGES, normalize_embeddings=True)
print(f"Passage matrix shape: {passage_vectors.shape}\n")

def top_k(query: str, k: int = 3) -> list[tuple[float, str]]:
    qv = model.encode(query, normalize_embeddings=True)
    scores = passage_vectors @ qv          # shape: (num_passages,)
    ranked = np.argsort(scores)[::-1][:k]
    return [(float(scores[i]), PASSAGES[i]) for i in ranked]

queries = [
    "How do I calculate safety stock?",
    "What should I know about electronics inventory?",
    "Tell me about demand patterns for consumer goods.",
]

for query in queries:
    print(f"Query: {query!r}")
    for score, passage in top_k(query):
        print(f"  {score:.3f}  {passage}")
    print()