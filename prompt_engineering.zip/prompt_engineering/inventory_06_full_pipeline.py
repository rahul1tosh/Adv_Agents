import os
import json
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

load_dotenv()

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0,
    api_key=os.environ.get("GROQ_API_KEY")
)

extract_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are a parameter extraction assistant. Extract inventory parameters from the user's natural language query.

Return ONLY a JSON object with these four keys (no other text):
{{"current_stock": <number>, "lead_time": <number>, "avg_daily_demand": <number>, "service_level": <number>}}

- current_stock: units currently on hand
- lead_time: days to receive a new shipment
- avg_daily_demand: average units sold/consumed per day
- service_level: target service level as a percentage (e.g. 95 for 95%)

If any parameter is missing or unclear, set its value to null."""),
    ("human", "{user_message}")
])

compute_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are an inventory planning expert. Given inventory parameters, compute the desired stock level.

Use this formula:
- Safety Stock = Z-score(service_level) * sqrt(lead_time) * average_daily_demand
- Desired Stock = (average_daily_demand * lead_time) + Safety Stock

Common Z-scores: 90% -> 1.28, 95% -> 1.65, 99% -> 2.33

Show your step-by-step calculation. End your response with a line:
DESIRED_STOCK: <number>"""),
    ("human", """Current Stock: {current_stock}
Lead Time (days): {lead_time}
Average Daily Demand: {avg_daily_demand}
Service Level: {service_level}%""")
])

reorder_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are an inventory planning advisor. Given the computation below and the current stock,
determine the reorder quantity and provide a clear recommendation.

Reorder Quantity = max(0, Desired Stock - Current Stock)

Provide:
1. The reorder quantity
2. Whether an immediate reorder is needed
3. A brief justification"""),
    ("human", """Current Stock: {current_stock}

Stock Computation:
{computation}""")
])

extract_chain = extract_prompt | llm | StrOutputParser()
compute_chain = compute_prompt | llm | StrOutputParser()
reorder_chain = reorder_prompt | llm | StrOutputParser()


def extract_params(user_message):
    raw = extract_chain.invoke({"user_message": user_message})
    params = json.loads(raw)
    missing = [k for k, v in params.items() if v is None]
    if missing:
        raise ValueError(f"Could not determine: {', '.join(missing)}")
    return params


def run_inventory_agent(user_message):
    params = extract_params(user_message)

    computation = compute_chain.invoke({
        "current_stock": params["current_stock"],
        "lead_time": params["lead_time"],
        "avg_daily_demand": params["avg_daily_demand"],
        "service_level": params["service_level"],
    })

    recommendation = reorder_chain.invoke({
        "current_stock": params["current_stock"],
        "computation": computation,
    })

    print(f"Params: {params}\n")
    print(f"--- Stock Computation ---\n{computation}\n")
    print(f"--- Reorder Recommendation ---\n{recommendation}")


user_message = "I have 500 units in my warehouse. It takes 7 days to get a new shipment, we sell about 50 units per day, and I want 95% service level. How much should I reorder?"
run_inventory_agent(user_message)
