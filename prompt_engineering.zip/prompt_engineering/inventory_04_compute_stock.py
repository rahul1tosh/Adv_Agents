import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

load_dotenv()

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0,
    api_key=os.environ.get("GROQ_API_KEY")
)

compute_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are an inventory planning expert. Given inventory parameters, compute the desired stock level.

Use this formula:
- Safety Stock = Z-score(service_level) * sqrt(lead_time) * average_daily_demand
- Desired Stock = (average_daily_demand * lead_time) + Safety Stock

Common Z-scores: 90% -> 1.28, 95% -> 1.65, 99% -> 2.33

Show your step-by-step calculation. End your response with a line:
DESIRED_STOCK: <number>"""),
    ("human", """Current Stock: {current_stock}
Lead Time (days): {lead_time}
Average Daily Demand: {avg_daily_demand}
Service Level: {service_level}%""")
])

chain = compute_prompt | llm | StrOutputParser()

result = chain.invoke({
    "current_stock": 500,
    "lead_time": 7,
    "avg_daily_demand": 50,
    "service_level": 95
})

print(result)
