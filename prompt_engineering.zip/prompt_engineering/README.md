# Prompt Engineering — Getting Started

A collection of Python scripts teaching prompt engineering concepts using LangChain, DSPy, and Groq.

## Prerequisites

- Python 3.11+
- A [Groq API key](https://console.groq.com/) (free tier available)
- `uv` package manager

---

## Install `uv`

### Mac / Linux
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### Windows (PowerShell)
```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

After install, restart your terminal so `uv` is on your PATH.

---

## Setup from scratch

```bash
# 1. Clone / navigate to this directory
cd prompt_engineering

# 2. Create a virtual environment and install all dependencies
uv sync
```

### Set your API key

A `.env` file is already present. Open it and replace the placeholder with your real key:

```
GROQ_API_KEY="your-groq-api-key"   # https://console.groq.com/keys
```

**Mac / Linux**
```bash
nano .env        # edit, then Ctrl+O to save, Ctrl+X to exit
# or
open -e .env     # opens in TextEdit
```

**Windows**
```powershell
notepad .env
```

Get your free key at https://console.groq.com/keys — sign in, click **Create API Key**, copy it, and paste it in place of `your-groq-api-key`.

---

## Running the scripts

Activate the virtual environment first:

### Mac / Linux
```bash
source .venv/bin/activate
python prompt_01_hello_llm.py
```

### Windows (PowerShell)
```powershell
.venv\Scripts\Activate.ps1
python prompt_01_hello_llm.py
```

Or run without activating using `uv run`:

```bash
uv run prompt_01_hello_llm.py
```

---

## Script progression

| File | Topic |
|------|-------|
| `prompt_01_hello_llm.py` | Basic LLM call |
| `prompt_02_no_memory.py` | Stateless calls |
| `prompt_03_prompt_template.py` | Simple templates |
| `prompt_04_advanced_template.py` | Advanced templating |
| `prompt_05_multiturn_chat.py` | Multi-turn conversation |
| `prompt_06_zeroshot.py` | Zero-shot prompting |
| `prompt_07_fewshot.py` | Few-shot prompting |
| `prompt_08_chain_of_thought.py` | Chain of thought |
| `prompt_09_prompt_chaining.py` | Chaining multiple prompts |
| `prompt_10_dspy_structured.py` | Structured outputs with DSPy |
| `prompt_11_system_message.py` | System message usage |
| `inventory_01_llm_call.py` – `inventory_07_gradio_ui.py` | End-to-end inventory use case |

Work through the files in order — each builds on the previous one.

---

## Adding a new dependency

```bash
uv add some-package
```

This updates `pyproject.toml` and re-locks automatically.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `uv: command not found` | Restart terminal after install, or add `~/.cargo/bin` to PATH |
| `ModuleNotFoundError` | Run `uv sync` again, make sure venv is activated |
| API errors | Check your `GROQ_API_KEY` in `.env` |
| Python version mismatch | Install Python 3.11+ via `uv python install 3.11` |
