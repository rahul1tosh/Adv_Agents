import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate

load_dotenv()

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    api_key=os.environ.get("GROQ_API_KEY")
)

template = PromptTemplate.from_template("""Classify the sentiment of the following customer product review
as positive, negative, or neutral.

Here are a few examples:

Review: The shoes fit perfectly and the quality is amazing.
Sentiment: positive

Review: The delivery was late and the product was damaged.
Sentiment: negative

Review: The packaging was okay, nothing special.
Sentiment: neutral

Review: {review}
Sentiment:
Answer concisely in 1 or two words
""")

chain = template | llm

reviews = [
    "The headphones have excellent sound quality, totally worth the price!",
    "I'm not happy, the phone case broke after two days of use.",
    "The product is fine, but I don't feel strongly about it either way."
]

for review in reviews:
    result = chain.invoke({"review": review}).content
    print(f"Review: {review}")
    print(f"Sentiment: {result}\n")
