import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq

load_dotenv()

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    api_key=os.environ.get("GROQ_API_KEY")
)

response1 = llm.invoke("Tell me about India")

response2 = llm.invoke("Tell me what is its capital?") # No idea of previous question
