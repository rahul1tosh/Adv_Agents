import os
import time
from dotenv import load_dotenv
import dspy

load_dotenv()

lm = dspy.LM(
    model="groq/llama-3.1-8b-instant",
    api_key=os.environ.get("GROQ_API_KEY"),
    max_tokens=600
)

dspy.settings.configure(lm=lm)

class CityInfo(dspy.Signature):
    """Return structured facts about a city in JSON format."""
    city = dspy.InputField(desc="Name of the city")
    output = dspy.OutputField(desc="JSON with keys: history, culture, food")

city_info = dspy.Predict(CityInfo)

cities = ["Tokyo", "Mumbai", "London", "Paris"]

for city in cities:
    print(f"\n--- Information about {city} ---")
    response = city_info(city=city)
    print(response.output)
    time.sleep(2)
