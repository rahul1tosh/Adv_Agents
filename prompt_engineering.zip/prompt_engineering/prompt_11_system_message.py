import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.messages import SystemMessage, HumanMessage

load_dotenv()

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    api_key=os.environ.get("GROQ_API_KEY")
)

def translate_to_hindi(text):
    messages = [
        SystemMessage(content="You are a helpful assistant that translates English to Hindi. Just translate the given sentence. Do not answer the question"),
        HumanMessage(content=text)
    ]
    response = llm.invoke(messages)
    print(response.content)

translate_to_hindi("Delhi has Qutub Minar")
translate_to_hindi("What is the capital of France?")
translate_to_hindi("Machine learning is a subset of artificial intelligence.")
