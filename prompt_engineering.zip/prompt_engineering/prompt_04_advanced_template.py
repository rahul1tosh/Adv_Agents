import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate

load_dotenv()

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    api_key=os.environ.get("GROQ_API_KEY")
)

template = PromptTemplate(
    input_variables=["subject", "audience", "tone", "length"],
    template="""
You are an expert educator. Create a {length} explanation about {subject}
for {audience}. Use a {tone} tone and include practical examples.

Topic: {subject}
Target Audience: {audience}
Tone: {tone}
Length: {length}

Your explanation:
"""
)

chain = template | llm
response = chain.invoke({
    "subject": "Chemistry",
    "audience": "High School Students",
    "tone": "Professional",
    "length": "100 words"
})
print(response.content)


import gradio as gr

class App:
    def __init__(self):
        self.chain = template | llm

    def generate(self, subject, audience, tone, length):
        response = self.chain.invoke({
            "subject": subject,
            "audience": audience,
            "tone": tone,
            "length": length
        })
        return response.content

    def launch(self):
        ui = gr.Interface(
            fn=self.generate,
            inputs=[
                gr.Textbox(label="Subject", value="Chemistry"),
                gr.Textbox(label="Audience", value="High School Students"),
                gr.Dropdown(["Professional", "Casual", "Friendly", "Academic"], label="Tone", value="Professional"),
                gr.Dropdown(["50 words", "100 words", "200 words", "500 words"], label="Length", value="100 words"),
            ],
            outputs=gr.Textbox(label="Explanation", lines=10),
            title="AI Educator",
        )
        ui.launch()

if __name__ == "__main__":
    App().launch()
