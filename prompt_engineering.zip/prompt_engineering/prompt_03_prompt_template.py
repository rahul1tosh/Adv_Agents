import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate

load_dotenv()

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    api_key=os.environ.get("GROQ_API_KEY")
)

template = PromptTemplate(
    input_variables=["topic"],
    # template="Provide a brief explanation of {topic} and list its three main components."
    template="Explain like Shakespear this topic {topic}"
)

chain = template | llm
response = chain.invoke({"topic": "Gravity"})
print(response.content)
