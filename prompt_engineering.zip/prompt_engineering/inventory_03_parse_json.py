import os
import json
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

load_dotenv()

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0,
    api_key=os.environ.get("GROQ_API_KEY")
)

extract_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are a parameter extraction assistant. Extract inventory parameters from the user's natural language query.

Return ONLY a JSON object with these four keys (no other text):
{{"current_stock": <number>, "lead_time": <number>, "avg_daily_demand": <number>, "service_level": <number>}}

- current_stock: units currently on hand
- lead_time: days to receive a new shipment
- avg_daily_demand: average units sold/consumed per day
- service_level: target service level as a percentage (e.g. 95 for 95%)

If any parameter is missing or unclear, set its value to null."""),
    ("human", "{user_message}")
])

chain = extract_prompt | llm | StrOutputParser()

user_message = "I have 500 units in stock, lead time is 7 days, we sell 50 per day, and I need 95% service level."
raw = chain.invoke({"user_message": user_message})
params = json.loads(raw)

print("Extracted parameters:")
for key, value in params.items():
    print(f"  {key}: {value}")

missing = [k for k, v in params.items() if v is None]
if missing:
    print(f"\nMissing: {missing}")
else:
    print("\nAll parameters extracted successfully.")
