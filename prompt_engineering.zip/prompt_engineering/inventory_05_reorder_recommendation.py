import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

load_dotenv()

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    temperature=0,
    api_key=os.environ.get("GROQ_API_KEY")
)

reorder_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are an inventory planning advisor. Given the computation below and the current stock,
determine the reorder quantity and provide a clear recommendation.

Reorder Quantity = max(0, Desired Stock - Current Stock)

Provide:
1. The reorder quantity
2. Whether an immediate reorder is needed
3. A brief justification"""),
    ("human", """Current Stock: {current_stock}

Stock Computation:
{computation}""")
])

chain = reorder_prompt | llm | StrOutputParser()

computation = """
Safety Stock = 1.65 * sqrt(7) * 50 = 218.4
Desired Stock = (50 * 7) + 218.4 = 568.4
DESIRED_STOCK: 568
"""

result = chain.invoke({
    "current_stock": 500,
    "computation": computation
})

print(result)
