import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda

load_dotenv()

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    api_key=os.environ.get("GROQ_API_KEY")
)

summarize_chain = PromptTemplate(
    input_variables=["review"],
    template="Summarize the following customer review into a single sentence:\n\nReview: {review}\n\nSummary:"
) | llm

sentiment_chain = PromptTemplate(
    input_variables=["summary"],
    template="Classify the sentiment of the following review summary as positive, negative, or neutral:\n\nSummary: {summary}\n\nSentiment:"
) | llm

suggest_chain = PromptTemplate(
    input_variables=["sentiment"],
    template="Based on the following sentiment, provide a brief suggestion for the seller:\n\nSentiment: {sentiment}\n\nSuggestion:"
) | llm

def extract(x):
    return x.content if hasattr(x, "content") else str(x)

full_chain = (
    summarize_chain
    | RunnableLambda(lambda x: {"summary": extract(x)})
    | sentiment_chain
    | RunnableLambda(lambda x: {"sentiment": extract(x)})
    | suggest_chain
)

review = "The product arrived late and was slightly damaged. I am very disappointed with the quality and the delivery service. I would not recommend this product."

result = full_chain.invoke({"review": review})
print(f"Review:\n{review}\n")
print(f"Suggestion:\n{extract(result)}")
