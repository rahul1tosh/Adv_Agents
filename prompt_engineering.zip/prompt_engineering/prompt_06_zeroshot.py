import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate

load_dotenv()

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    api_key=os.environ.get("GROQ_API_KEY")
)

template = PromptTemplate.from_template("""Classify the sentiment of the following text as positive, negative, or neutral.
Do not explain your reasoning, just provide the classification.

Text: {text}

Sentiment:""")

chain = template | llm

texts = [
    "The product met my expectation. Great value for money",
    "The weather today is quite typical for this time of year.",
    "I wish the restaurant wait times were shorter. We wasted a lot of time"
]

for text in texts:
    result = chain.invoke({"text": text}).content
    print(f"Text: {text}")
    print(f"Sentiment: {result}\n")
